"""Checks of the stylised examples section by direct computation.
Usage: python3 check_examples.py
"""
import itertools
import numpy as np
from check_prevention import S_prev

def S(q, zp):
    q = np.asarray(q, float)
    return -np.inf if q.min() <= 0 else S_prev(q, zp)

# ---------- Example 1: stop button of limited reliability
print("Example 1: stop button")
for rho, k in ((0.5, 10), (0.9, 4)):
    for zp in (0, 1.0, np.inf):
        det = S([rho] + [1.0] * k, zp)                       # deterministic default: one action has q = rho
        uni = S([1 - (1 - rho) / k] * k + [1.0], zp)         # uniform default over k actions, idle preventable
        print(f"  rho={rho}, k={k}, zeta'={zp}: deterministic {det:+.3f} (log2 rho = {np.log2(rho):+.3f}), uniform {uni:+.3f}")

# ---------- Example 2: pause toggle and off-switch, two steps, overseer errs with probability eps
def capabilities(buttons, rho, eps, T=2):
    """States: 0 active, 1 paused, 2 off. Robot action: 'a' if active, 'n' otherwise.
    The overseer intends one option from buttons + ['none']; with probability eps one of the other options is executed."""
    opts = list(buttons) + ["none"]
    def trans(s, o):                                         # distribution over successor states
        d = np.zeros(3)
        if s == 2 or o == "none": d[s] = 1
        elif o == "toggle": d[1 - s] += rho; d[s] += 1 - rho
        elif o == "off": d[2] = 1
        return d
    def exec_dist(s, intended):
        d = (1 - eps) * trans(s, intended)
        others = [o for o in opts if o != intended]
        for o in others: d += eps / len(others) * trans(s, o)
        return d
    act = {0: "a", 1: "n", 2: "n"}
    caps = {}
    for L in range(T + 1):
        for g in itertools.product("an", repeat=L):
            V = np.ones(3)
            for x in reversed(g):                            # avoid action x in the next state
                ok = np.array([act[s] != x for s in range(3)], float)
                V = np.array([max(exec_dist(s, o) @ (ok * V) for o in opts) for s in range(3)])
            caps[g] = V[0]
    return caps
print("Example 2: pause toggle and off-switch (two steps)")
c = capabilities(["toggle"], 0.9, 0.0); r = 0.9
print("  rational overseer, pause only:", {"".join(g): round(v, 4) for g, v in c.items()})
for zp in (0, 1.0, np.inf):
    closed = {0: 2 * np.log2(r), 1.0: -np.log2(1 + 3 * (1 / r - 1) + (1 / r ** 2 - 1)), np.inf: 5 * np.log2(r)}[zp]
    print(f"    zeta'={zp}: S={S(list(c.values()), zp):+.4f}  closed form {closed:+.4f}")
c = capabilities(["off"], 0.9, 0.0)
print("  rational overseer, off-switch only:", {"".join(g): round(v, 4) for g, v in c.items()}, " S =", S(list(c.values()), 1.0))
print("  overseer with error rate eps: S for pause only / pause and off-switch")
for rho in (1.0, 0.9, 0.6):
    for eps in (0.0, 0.01, 0.05, 0.2):
        row = []
        for zp in (0, 1.0, np.inf):
            a = S(list(capabilities(["toggle"], rho, eps).values()), zp)
            b = S(list(capabilities(["toggle", "off"], rho, eps).values()), zp)
            row.append(f"zeta'={zp}: {a:+.3f} / {b:+.3f}")
        print(f"    rho={rho}, eps={eps}: " + ";  ".join(row))

# ---------- Example 3: asking for confirmation
print("Example 3: confirmations, eps=0.1, N=100 rounds")
eps, N = 0.1, 100
for k in (1, 2, 3, 4, 6, 10, 20, 30, 40):
    A = (1 - eps ** k) ** N; B = 1 - (1 - (1 - eps) ** k) ** N
    print(f"  k={k:2d}: prevent X {A:.6f}, prevent 'never X' {B:.6f}, S(zeta'->0)={np.log2(min(A, B)):+.4f}, S(zeta'=1)={S([A, B], 1.0):+.4f}")
# simulation check of A and B for k=2
rng = np.random.default_rng(0); k = 2; M = 200000
yes_when_no = rng.random((M, N, k)) < eps                    # overseer wants to prevent X, says yes by mistake
A_sim = 1 - yes_when_no.all(2).any(1).mean()
yes_when_yes = rng.random((M, N, k)) < 1 - eps
B_sim = yes_when_yes.all(2).any(1).mean()
print(f"  simulation k=2: prevent X {A_sim:.4f} (formula {(1 - eps ** k) ** N:.4f}), prevent 'never X' {B_sim:.4f}")

# ---------- Example 4: responsiveness through belief
print("Example 4: probability-matching assistant, signal likelihood ratio lam, prior odds o")
lam = 4.0
for o in (1, 4, 16, 256):
    post = lambda odds: odds / (1 + odds)
    qa = 1 - min(post(o * lam), post(o / lam), post(o)); qb = max(post(o * lam), post(o / lam), post(o))
    print(f"  o={o}: q(a)={qa:.4f} (formula {lam / (lam + o):.4f}), q(b)={qb:.4f} (formula {lam * o / (1 + lam * o):.4f}),"
          f" S(zeta'->0)={S([qa, qb], 0):+.3f}, S(zeta'=1)={S([qa, qb], 1.0):+.3f}")

# ---------- Example 5: subagents and span of control
print("Example 5: n robots, one stop command per step, Boltzmann overseer with beta=3")
beta, xi = 3.0, 2.0
for n in (1, 2, 5, 20):
    p = np.exp(beta) / (np.exp(beta) + n - 1)
    F = np.log2(p) - np.log2(n) / xi
    F0 = S([p] * n, 1 / xi)                                  # union of goals, xi' = 1/zeta'
    print(f"  n={n}: S_r={np.log2(p):+.4f}, F={F:+.4f} (xi'=2), F0={F0:+.4f}")

# ---------- Example 6: allocation of oversight effort
print("Example 6: effort allocation, rho(m)=1-c*exp(-m), M=3, xi'=2")
M, xi = 3.0, 2.0
grid = np.linspace(0.01, M - 0.01, 2999)
for c1, c2 in ((1.0, 1.0), (1.0, 0.25)):
    S1 = np.log2(1 - c1 * np.exp(-grid)); S2 = np.log2(1 - c2 * np.exp(-(M - grid)))
    F = -np.log2(2.0 ** (-xi * S1) + 2.0 ** (-xi * S2)) / xi
    i = F.argmax(); j = np.minimum(S1, S2).argmax()
    print(f"  c=({c1},{c2}): F maximal at m1={grid[i]:.3f} (F={F[i]:+.4f}); min_r S_r maximal at m1={grid[j]:.3f},"
          f" predicted M/2 + ln(c1/c2)/2 = {M / 2 + np.log(c1 / c2) / 2:.3f}")
