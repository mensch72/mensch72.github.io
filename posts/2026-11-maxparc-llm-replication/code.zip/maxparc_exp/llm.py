"""Anthropic API access with full JSONL logging, deterministic replay (resume),
and a hard budget cap.

Logging: every API call writes one JSONL record with the request parameters,
the messages appended since the previous call of that participant
("new_messages"), the message count and a SHA-256 of the complete request
body, plus the complete response (all content blocks incl. thinking summaries),
usage and computed cost. The full request of any call is reconstructable from
the participant's earlier records; logging every full request would make the
log quadratic in conversation length.

The API key is read from ANTHROPIC_API_KEY or MAXPARC_API_KEY and is never
written anywhere.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import time
from pathlib import Path

MODEL = "claude-haiku-5-5"
MAX_TOKENS = 16000
# Default sampling (no temperature etc.). Thinking: Haiku 5.5 runs adaptive
# thinking by default; display="summarized" only changes what is returned
# (summaries instead of empty strings), not the model's behaviour.
THINKING = {"type": "adaptive", "display": "summarized"}
CACHE = {"type": "ephemeral"}  # automatic prompt caching: cost only

# USD per token: input, output, cache write, cache read, long-prompt multiplier (prompts > 100K tokens).
# Haiku 5.5: $0.10/$0.50 per MTok, x5 above 100K. Sonnet 5.5: $2/$10, cache reads $0.10; cache writes
# assumed at the usual 1.25 x input; no long-prompt premium applied (prompts here stay far below 100K).
PRICES = {
    "claude-haiku-5-5": (0.10e-6, 0.50e-6, 0.125e-6, 0.01e-6, 5.0),
    "claude-sonnet-5-5": (2.00e-6, 10.00e-6, 2.50e-6, 0.10e-6, 1.0),
}


def cost_of(usage: dict, model: str = MODEL) -> float:
    p_in, p_out, p_cw, p_cr, long_mult = PRICES[model]
    inp = usage.get("input_tokens", 0) or 0
    cw = usage.get("cache_creation_input_tokens", 0) or 0
    cr = usage.get("cache_read_input_tokens", 0) or 0
    out = usage.get("output_tokens", 0) or 0
    mult = long_mult if inp + cw + cr > 100_000 else 1.0
    return mult * (p_in * inp + p_cw * cw + p_cr * cr + p_out * out)


class BudgetExceeded(RuntimeError):
    pass


# ---------------------------------------------------------------- OpenRouter (open-weight models)
# OpenAI-style chat completions at openrouter.ai. Default sampling and the model's default reasoning
# behaviour (no temperature, no reasoning parameter). The cost of each call is read from the
# response's usage.cost (USD, as billed by OpenRouter); the budget cap uses it.
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
OR_MAX_ATTEMPTS = 8


def to_openai_messages(messages: list) -> list:
    """Anthropic-style history -> OpenAI chat messages. Only the visible text is passed back
    (reasoning is logged but not returned to the model in later turns)."""
    out = []
    for m in messages:
        c = m["content"]
        if isinstance(c, list):
            c = "\n".join(b.get("text", "") for b in c if b.get("type") == "text") or "(empty response)"
        out.append({"role": m["role"], "content": c})
    return out


def normalise_openrouter(r: dict) -> dict:
    """OpenRouter response -> the response shape used by the Anthropic path."""
    ch = (r.get("choices") or [{}])[0]
    msg = ch.get("message") or {}
    content = []
    reasoning = msg.get("reasoning")
    if not reasoning and msg.get("reasoning_details"):
        reasoning = "\n".join(d.get("text") or d.get("summary") or "" for d in msg["reasoning_details"])
    if reasoning:
        content.append({"type": "thinking", "thinking": reasoning})
    if msg.get("content"):
        content.append({"type": "text", "text": msg["content"]})
    fr = ch.get("finish_reason")
    stop = {"stop": "end_turn", "length": "max_tokens", "content_filter": "refusal"}.get(fr, fr or "unknown")
    if msg.get("refusal"):
        stop = "refusal"
    u = r.get("usage") or {}
    cached = (u.get("prompt_tokens_details") or {}).get("cached_tokens") or 0
    usage = {"input_tokens": (u.get("prompt_tokens") or 0) - cached, "cache_read_input_tokens": cached,
             "cache_creation_input_tokens": 0, "output_tokens": u.get("completion_tokens") or 0,
             "reasoning_tokens": (u.get("completion_tokens_details") or {}).get("reasoning_tokens"),
             "cost": u.get("cost")}
    return {"id": r.get("id"), "model": r.get("model"), "provider": r.get("provider"), "content": content,
            "reasoning_details": msg.get("reasoning_details"), "system_fingerprint": r.get("system_fingerprint"),
            "stop_reason": stop, "finish_reason": fr, "native_finish_reason": ch.get("native_finish_reason"),
            "stop_details": None, "usage": usage}


class LLM:
    def __init__(self, log_path: Path, budget_usd: float, concurrency: int = 32, offline: bool = False,
                 fake: bool = False, model: str = MODEL, effort: str | None = None,
                 backend: str = "anthropic"):
        self.backend = backend  # "anthropic" or "openrouter"
        self.model_opts = {}  # OpenRouter: extra request fields per model, e.g. {"reasoning": {"enabled": True}}
        if backend == "anthropic" and model not in PRICES:
            raise ValueError(f"No prices for {model}")
        self.model, self.effort = model, effort  # effort None = model default (no output_config sent)
        self.fake = fake
        self.log_dir = Path(log_path)  # directory: one JSONL file per session
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.replay = {}
        for f in sorted(self.log_dir.glob("*.jsonl")):
            with open(f) as fh:
                for line in fh:
                    rec = json.loads(line)
                    if "response" in rec:
                        self.replay[rec["key"]] = rec
        self.budget = budget_usd
        self.spent_new = 0.0
        self.spent_replayed = 0.0
        self.calls_new = 0
        self.calls_replayed = 0
        self.sem = asyncio.Semaphore(concurrency)
        self.offline = offline
        self._client = None
        self._fh = {}

    def client(self):
        if self._client is None:
            import anthropic
            key = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("MAXPARC_API_KEY")
            if not key:
                raise RuntimeError("Set ANTHROPIC_API_KEY (or MAXPARC_API_KEY).")
            self._client = anthropic.AsyncAnthropic(api_key=key, max_retries=10, timeout=600)
        return self._client

    def _write(self, rec):
        sess = rec.get("session", "misc")
        if sess not in self._fh:
            self._fh[sess] = open(self.log_dir / f"{sess}.jsonl", "a")
        self._fh[sess].write(json.dumps(rec, ensure_ascii=False) + "\n")
        self._fh[sess].flush()

    def or_client(self):
        if getattr(self, "_or", None) is None:
            import httpx2
            # The key is read from OPENROUTER_API_KEY; in Claude Code cloud sessions the network
            # proxy injects the saved credential, so a placeholder is sent instead.
            key = os.environ.get("OPENROUTER_API_KEY") or "proxy-injected"
            self._or = httpx2.AsyncClient(timeout=httpx2.Timeout(600.0, connect=30.0),
                                          headers={"Authorization": f"Bearer {key}",
                                                   "X-Title": "maxparc-replication"})
        return self._or

    async def call(self, key: str, meta: dict, messages: list, new_messages: list, model: str | None = None) -> dict:
        if self.backend == "openrouter" and not self.fake:
            return await self._call_openrouter(key, meta, messages, new_messages, model)
        extra = {"output_config": {"effort": self.effort}} if self.effort else {}
        body = {"model": self.model, "max_tokens": MAX_TOKENS, "thinking": THINKING,
                "cache_control": CACHE, "messages": messages, **extra}
        digest = hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        if key in self.replay:
            rec = self.replay[key]
            if rec["request"]["sha256"] != digest:
                raise RuntimeError(f"Replay mismatch for {key}: request differs from the logged one.")
            self.calls_replayed += 1
            self.spent_replayed += rec["cost_usd"]
            return rec["response"]
        if self.offline:
            raise RuntimeError(f"Offline mode: no logged response for {key}")
        if self.fake:
            from .fake import fake_response
            response = fake_response(key, messages)
            rec = {"key": key, **meta, "time": time.time(), "fake": True,
                   "request": {"model": "FAKE", "n_messages": len(messages), "new_messages": new_messages,
                               "sha256": digest}, "response": response, "cost_usd": 0.0}
            self._write(rec)
            self.replay[key] = rec
            self.calls_new += 1
            return response
        if self.spent_new >= self.budget:
            raise BudgetExceeded(f"Budget of ${self.budget:.2f} reached (spent ${self.spent_new:.4f}).")
        async with self.sem:
            t0 = time.time()
            try:
                resp = await self.client().messages.create(
                    model=self.model, max_tokens=MAX_TOKENS, thinking=THINKING,
                    cache_control=CACHE, messages=messages, **extra)
            except Exception as e:  # SDK already retried transient errors
                self._write({"key": key, **meta, "time": t0, "error": f"{type(e).__name__}: {e}"})
                raise
        r = resp.model_dump(mode="json", exclude_none=True)
        response = {"id": r.get("id"), "model": r.get("model"), "content": r.get("content", []),
                    "stop_reason": r.get("stop_reason"), "stop_details": r.get("stop_details"),
                    "usage": r.get("usage", {})}
        c = cost_of(response["usage"], self.model)
        self.spent_new += c
        self.calls_new += 1
        rec = {"key": key, **meta, "time": t0, "latency_s": round(time.time() - t0, 2),
               "request": {"model": self.model, "max_tokens": MAX_TOKENS, "thinking": THINKING, **extra,
                           "cache_control": CACHE, "n_messages": len(messages),
                           "new_messages": new_messages, "sha256": digest},
               "response": response, "cost_usd": c}
        self._write(rec)
        self.replay[key] = rec
        return response

    async def _call_openrouter(self, key, meta, messages, new_messages, model):
        if not model:
            raise ValueError("openrouter backend needs a model per participant")
        body = {"model": model, "max_tokens": MAX_TOKENS, "messages": to_openai_messages(messages),
                "usage": {"include": True}, **self.model_opts.get(model, {})}
        digest = hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        if key in self.replay:
            rec = self.replay[key]
            if rec["request"]["sha256"] != digest:
                raise RuntimeError(f"Replay mismatch for {key}: request differs from the logged one.")
            self.calls_replayed += 1
            self.spent_replayed += rec["cost_usd"]
            return rec["response"]
        if self.spent_new >= self.budget:
            raise BudgetExceeded(f"Budget of ${self.budget:.2f} reached (spent ${self.spent_new:.4f}).")
        async with self.sem:
            t0, err, r = time.time(), None, None
            for attempt in range(OR_MAX_ATTEMPTS):
                try:
                    h = await self.or_client().post(OPENROUTER_URL, json=body)
                    j = h.json() if h.content else {}
                    if h.status_code == 200 and not j.get("error") and j.get("choices") \
                            and (j["choices"][0].get("finish_reason") or "") != "error":
                        r = j
                        break
                    err = f"HTTP {h.status_code}: {json.dumps(j.get('error') or j)[:500]}"
                    if h.status_code in (400, 401, 402, 403, 404):
                        break  # not transient
                except Exception as e:  # network errors, timeouts, invalid JSON
                    err = f"{type(e).__name__}: {e}"
                self._write({"key": key, **meta, "model": model, "time": time.time(), "retry": attempt, "error": err})
                await asyncio.sleep(min(60, 2 ** attempt))
            if r is None:
                raise RuntimeError(f"OpenRouter call {key} failed: {err}")
        response = normalise_openrouter(r)
        c = float(response["usage"].get("cost") or 0.0)
        self.spent_new += c
        self.calls_new += 1
        rec = {"key": key, **meta, "model": model, "time": t0, "latency_s": round(time.time() - t0, 2),
               "request": {"backend": "openrouter", "model": model, "max_tokens": MAX_TOKENS,
                           **self.model_opts.get(model, {}),
                           "n_messages": len(messages), "new_messages": new_messages, "sha256": digest},
               "response": response, "raw_usage": r.get("usage"), "cost_usd": c}
        self._write(rec)
        self.replay[key] = rec
        return response
