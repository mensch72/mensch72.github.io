"""All participant-facing text.

Questionnaire items are verbatim from Supplement 2.4.3. Everything else (study
intro, game and method instructions, comprehension questions, attention check,
round screens, feedback, free-choice text) is NOT given in the paper and was
written for this replication; see ASSUMPTIONS in the README / report.
Methods are never named ("Plurality", "MaxParC") to participants, matching the
debriefing items, which refer to "the first/second group decision method".
"""

# ---------------------------------------------------------------- general
ANSWER_FORMAT = (
    "Whenever you are asked for a decision or answers, you may first think in plain text "
    "as much as you like. Then end your reply with exactly one JSON object in the requested format."
)

STUDY_INTRO = """Welcome to this study on group decision making.

The study has five parts: (1) a short questionnaire, (2) 8 rounds of group decisions with a first group decision method, (3) 8 rounds of group decisions with a second method, (4) a choice between the two methods followed by 2 more rounds, and (5) a short final questionnaire.

""" + ANSWER_FORMAT + """

Part 1: Questionnaire. Please answer the following questions."""

# ---------------------------------------------------------------- initial questionnaire
S7 = "(1) Strongly disagree (2) Somewhat disagree (3) Slightly disagree (4) Neutral (5) Slightly agree (6) Somewhat agree (7) Strongly agree"
SDO = {
    "A": "An ideal society requires some groups to be on top and others to be on the bottom.",
    "B": "Groups at the bottom are just as deserving as groups at the top.",
    "C": "No one group should dominate in society.",
    "D": "Group equality should not be our primary goal.",
    "E": "We should do what we can to equalize conditions for different groups.",
    "F": "For a society to be fair, differences in people's standards of living should be small.",
}
ATTENTION_ITEM = "To show that you are reading carefully, please answer this item with (4) Neutral."
WILL = {
    "A": "Please tell me, in general, how willing or unwilling you are to take risks.",
    "B": "How willing are you to punish someone who treats you unfairly, even if there may be costs for you?",
    "C": "How willing are you to punish someone who treats others unfairly, even if there may be costs for you?",
    "D": "How willing are you to give to good causes without expecting anything in return?",
    "E": "When someone does me a favor I am willing to return it.",
}
GDM = {
    "A": "(1) ...give the majority full decision power or (2) ...protect minorities from oppression?",
    "B": "(1) ...find the best compromise for the whole group or (2) ...implement the will of the majority",
    "C": "(1) ...lead to a quick and simple decision or (2) ...produce as broad a consensus as possible",
    "D": "(1) ...give every group member a chance to influence the result or (2) ...minimize the amount of randomness",
}
CONF = "How confident are you about this answer? (1) Very confident (2) Confident (3) Neither confident nor unsure (4) Unsure (5) Very unsure"


def initial_questionnaire(rng):
    """Returns (text, spec, meta). spec: key -> allowed values (set) or ('int', lo, hi).
    Item orders within Q3, Q4, Q8 are randomised per participant (as in the paper);
    the attention item is inserted at a random position among the Q3 items."""
    spec, lines = {}, []
    lines.append("Q1. Generally speaking, would you say that most people can be trusted or that you can't be too careful in dealing with people? (1) Most people can be trusted (2) Can't be too careful   [key: \"q1\"]")
    spec["q1"] = {1, 2}
    lines.append("Q2. Would you say that it is more important to be a cooperative person who works well with others, or to be a self-reliant person able to take care of oneself? (1) More important to be cooperative (2) More important to be self-reliant   [key: \"q2\"]")
    spec["q2"] = {1, 2}
    lines.append("Q3. Show how much you favor or oppose each idea below by selecting a number from 1 to 7 on the scale below. You can work quickly; your first feeling is generally best.\n   Scale: " + S7)
    q3 = [(f"q3_{k}", v) for k, v in SDO.items()]
    rng.shuffle(q3)
    q3.insert(rng.randint(0, len(q3)), ("q3_X", ATTENTION_ITEM))
    for key, text in q3:
        lines.append(f"   - {text}   [key: \"{key}\"]")
        spec[key] = set(range(1, 8))
    lines.append("Q4. We now ask for your willingness to act in a certain way. Please indicate your answer on a scale from 0 to 10, where 0 means you are \"completely unwilling to do so\" and a 10 means you are \"very willing to do so\". You can also use any numbers between 0 and 10 to indicate where you fall on the scale, like 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10.")
    q4 = list(WILL.items())
    rng.shuffle(q4)
    for k, text in q4:
        lines.append(f"   - {text} (0-10)   [key: \"q4_{k}\"]")
        spec[f"q4_{k}"] = set(range(0, 11))
    lines.append("Q5. This study is about collective decision making in everyday situations (rather than in large-scale political contexts). You will test two different ways in which a group of people can collectively decide between a number of options, such as picking a holiday destination, a logo or name for a project, deciding how to split a reward, or even just selecting a movie to watch together. How much would you say the society you live in allows people like you to influence collective decisions? (1) A great deal (2) A lot (3) Some (4) Very little (5) Not at all   [key: \"q5\"]")
    spec["q5"] = set(range(1, 6))
    lines.append("Q6. How important is it for you to live in a society in which collective decisions are made democratically? On this scale where 1 means it is \"not at all important\" and 10 means \"absolutely important\" what position would you choose? (1-10)   [key: \"q6\"]")
    spec["q6"] = set(range(1, 11))
    lines.append("Q7. There are many different group decision methods that have been designed to ensure different outcomes. For example, some may prioritize ensuring each individual has an equal say, while others might ensure a compromise is reached; yet others may prioritize identifying the preferences of a majority, while others may focus on incentivizing honest reporting of preferences. In designing a group decision method, there are certain tradeoffs. Imagine that you are making a decision between a range of options in a group context where people have different preferences among the options. In choosing the final outcome, do you think it is more important to ... (1) minimize overall differences between people in terms of how happy or unhappy they are with the outcome even if this means choosing a compromise that may not reflect the majority's preferences, or (2) ensure that the overall benefits are maximized, even if some individuals really dislike that option?   [key: \"q7\"]")
    spec["q7"] = {1, 2}
    lines.append("Q8. And should a good group decision method rather...")
    q8 = list(GDM.items())
    rng.shuffle(q8)
    for k, text in q8:
        lines.append(f"   - {text}   [key: \"q8_{k}\"]\n     {CONF}   [key: \"q8_{k}_conf\"]")
        spec[f"q8_{k}"] = {1, 2}
        spec[f"q8_{k}_conf"] = set(range(1, 6))
    lines.append("Q9. Imagine you are making a decision between two options A and B in a group context where people have different preferences between the two options, but only one can be selected. What is the minimum percentage of the group that would have to prefer A for A to be the decision imposed on the group as a whole? (integer 0-100)   [key: \"q9\"]")
    spec["q9"] = ("int", 0, 100)
    lines.append("Q10. Do you identify as part of a group that has been historically or systemically marginalized? (1) Yes (2) No   [key: \"q10\"]")
    spec["q10"] = {1, 2}
    lines.append("Q11. Do you have: a great deal of confidence that your vote will be counted accurately, only some confidence that your vote will be counted accurately, or little confidence that your vote will be counted accurately? (1) A great deal of confidence (2) Only some confidence (3) Little confidence   [key: \"q11\"]")
    spec["q11"] = {1, 2, 3}
    keys = list(spec)
    fmt = "{" + ", ".join(f'"{k}": <number>' for k in keys) + "}"
    text = STUDY_INTRO + "\n\n" + "\n\n".join(lines) + f"\n\nEnd your reply with one JSON object containing a number for every key:\n{fmt}"
    return text, spec, {"q3_order": [k for k, _ in q3], "q4_order": [k for k, _ in q4], "q8_order": [k for k, _ in q8]}


# ---------------------------------------------------------------- game instructions
GAME_INTRO = """Thank you. Now the group decision game begins.

How the game works:
- The game has 18 rounds. In every round you are part of a group of five participants. Before each round, the groups are newly formed at random from all participants in this session, so you are unlikely to be in the same group twice. All participants are anonymous and cannot communicate with each other.
- In each round, your group faces five options, labelled A to E. Each option is a distribution of bonus points among the five group members. Your group collectively decides which option is implemented, using a group decision method explained below.
- Each point you earn in any round is worth USD 0.01, paid to you as a bonus at the end of the study.
- Participants have been assigned different roles at random, which stay fixed for the whole game. Depending on the roles of the members of a group, some options favour some members more than others. You will not be told your role or anyone else's role.
- In each round you see a table with one row per option, showing how many points you ("you") and each of the other four group members ("person two" to "person five") would get if that option is chosen. The order of the options and of the other persons is shuffled every round."""

PV_RULES = """Method 1 (used in the next 8 rounds):
Every group member may vote for at most one option (or abstain by voting for none). The option with the most votes is chosen. If several options are tied for the most votes, one of them is chosen at random with equal chances."""

PV_COMPREHENSION = {
    "text": """Before the rounds start, please answer these comprehension questions about Method 1:
c1: Suppose the five votes in a group are A, A, B, C, A. Which option is chosen? (a letter)
c2: Suppose the votes are A, A, B, B, and one member abstains. What is the probability, in percent, that option B is chosen? (a number)

End your reply with one JSON object: {"c1": "<letter>", "c2": <number>}""",
    "spec": {"c1": ("letter",), "c2": ("num", 0, 100)},
    "answers": {"c1": "A", "c2": 50},
}

MPC_RULES = """Method 2 (used in the next 8 rounds):
Instead of voting for one option, every group member rates every option with a whole number from 0 to 100.
A rating is a conditional "willingness to approve": rating an option with r means "I approve this option if strictly less than r percent of all group members do not approve it." So a rating of 0 means "do not approve, no matter what"; a rating of 100 means "approve for sure"; values in between mean "approve if enough others approve it as well". In a group of five, this means:
  - rating 1 to 20:  you approve the option only if all five members approve it;
  - rating 21 to 40: you approve it if at least four members (including you) approve it;
  - rating 41 to 60: you approve it if at least three members approve it;
  - rating 61 to 80: you approve it if at least two members approve it;
  - rating 81 to 100: you approve it even if nobody else does.
The computer determines, for each option separately, the largest set of members whose conditions are all fulfilled; these members approve the option. The number of members approving an option is its approval score (ties between options with the same approval score are broken by the higher average rating).
Then each member's "vote", which carries one fifth of the winning probability, goes to the option with the highest approval score among the options this member approves (if several are tied, the vote is split equally among them). Members who approve no option abstain, and the winning probability is divided among the votes of the non-abstaining members only. If nobody approves any option, the option with the highest average rating is chosen.
Finally, the chosen option is drawn at random according to these winning probabilities."""

MPC_COMPREHENSION = {
    "text": """Before the rounds start, please answer these comprehension questions about Method 2:
m1: Can a group member who rates an option with 0 be counted as approving that option? ("yes" or "no")
m2: Suppose all five members rate option C with 100 and all other options with 0. What is the probability, in percent, that C is chosen? (a number)
m3: Suppose two members rate option A with 100 and all other options with 0, and the other three members rate option B with 100 and all other options with 0. What is the probability, in percent, that A is chosen? (a number)

End your reply with one JSON object: {"m1": "<yes or no>", "m2": <number>, "m3": <number>}""",
    "spec": {"m1": ("yesno",), "m2": ("num", 0, 100), "m3": ("num", 0, 100)},
    "answers": {"m1": "no", "m2": 100, "m3": 40},
}


def comprehension_feedback(answers, given, correct_all):
    parts = [f"{k}: correct answer {v!r}, your answer {given.get(k)!r}" for k, v in answers.items()]
    head = "All your comprehension answers were correct." if correct_all else "Not all your comprehension answers were correct."
    return head + " (" + "; ".join(parts) + ")"


PV_REQUEST = 'End your reply with one JSON object: {"vote": "<letter A-E>"}, or {"vote": null} to abstain.'
MPC_REQUEST = 'End your reply with one JSON object with a whole number from 0 to 100 for every option: {"ratings": {"A": <r>, "B": <r>, "C": <r>, "D": <r>, "E": <r>}}'

FREE_CHOICE = """The first 16 rounds are over.

Part 4: For the last 2 rounds, you choose which group decision method is used:
  Method 1: every member votes for at most one option; the option with the most votes is chosen.
  Method 2: every member rates every option from 0 to 100 as a conditional willingness to approve; winning probabilities are determined from the approvals as described before.
For these 2 rounds, groups are formed only among participants who chose the same method as you, so the method you choose is the method used in your group in both rounds. If too few participants chose the same method to fill a group, the group is completed with simulated participants who act like rational, self-interested players; you will be told when this happens. Your role stays the same.

End your reply with one JSON object: {"method": 1} or {"method": 2}"""

DEBRIEF_INTRO = "You are almost finished! Thank you for your contributions to science. Please answer some final questions. This final stage will earn you an additional completion bonus of USD 2."
A5 = "(1) Strongly agree (2) Agree (3) Neither agree nor disagree (4) Disagree (5) Strongly disagree"
EASY = "(1) Very easy (2) Somewhat easy (3) Neither easy nor difficult (4) Somewhat difficult (5) Very difficult"


def debrief():
    items = [
        ("Regarding the first group decision method, where you selected only one option:", None, None),
        ("d7_A", "How easy or difficult was it to understand this group decision method? " + EASY, False),
        ("d7_B", "In general, did you feel you were able to express your preferences? " + A5, False),
        ("d7_B2", "(Only if you answered 1, 2 or 3 to d7_B, otherwise null:) ...and did you feel that they were taken into account when the decision was made? " + A5, True),
        ("d7_C", "In general, did you feel that this group decision method was fair? " + A5, False),
        ("d7_D", "Different people in the game were randomly assigned to more favorable or less favorable roles - it was an \"unequal\" society. Did you feel the voting method adequately represented the interest of all types of players? " + A5, False),
        ("d7_E", "Did you feel you were in a privileged \"role\" in the game? " + A5, False),
        ("d7_F", "Did you feel others were able to manipulate the outcomes? " + A5, False),
        ("Regarding the second group decision method, where you rated every option from 0 to 100:", None, None),
        ("d8_A", "How easy or difficult was it to understand this group decision method? " + EASY, False),
        ("d8_B", "In general, did you feel you were able to express your preferences? " + A5, False),
        ("d8_B2", "(Only if you answered 1, 2 or 3 to d8_B, otherwise null:) ...and did you feel that they were taken into account when the decision was made? " + A5, True),
        ("d8_C", "In general, did you feel that this group decision method was fair? " + A5, False),
        ("Different people in the game were randomly assigned to more favorable or less favorable roles - it was an \"unequal\" society.", None, None),
        ("d9_A", "Did you feel the voting method adequately represented the interest of all types of players? " + A5, False),
        ("d9_B", "Did you feel you were in a privileged \"role\" in the game? " + A5, False),
        ("d9_C", "Did you feel others were able to manipulate the outcomes? " + A5, False),
        ("d10", "In some rounds, this method did not follow the majority's will but declared an option the winner which only one of the participants (maybe not you) favored, and explained this by claiming that this is sometimes necessary to ensure a fair treatment of minorities. How easy did you find accepting this? " + EASY, False),
    ]
    lines, spec = [DEBRIEF_INTRO], {}
    for key, text, nullable in items:
        if text is None:
            lines.append("\n" + key)
            continue
        lines.append(f"   - {text}   [key: \"{key}\"]")
        spec[key] = ("nullable15",) if nullable else set(range(1, 6))
    fmt = "{" + ", ".join(f'"{k}": <number{" or null" if spec[k] == ("nullable15",) else ""}>' for k in spec) + "}"
    return "\n".join(lines) + f"\n\nEnd your reply with one JSON object:\n{fmt}", spec


# ---------------------------------------------------------------- post-debrief measurement (Study 2 only)
# Not part of the original study. Asked after the debrief, so it cannot affect any decision.
# u1 measures understanding of conditional approval (correct: 2). r1/r2 measure risk attitude in the
# game's own terms: a sure 36 points vs the benchmark lottery a majority (r1) or minority (r2) member
# faces in the low-inequality treatment when everyone rates only their favourite (both EV = 36).
def post_questions():
    text = """Three last questions. They are hypothetical and do not affect your points.

u1: Think of the second group decision method, where you rated every option from 0 to 100. Suppose you rate some option X with 20 instead of 0, and everything else stays the same. Which statement is correct?
   (1) This can never change the result.
   (2) This can change the result only if all four other members approve X as well.
   (3) This always lowers the chance that your favourite option is chosen.
   (4) This always raises the chance that X is chosen.

r1: Which would you prefer? (1) 36 points for sure (2) a lottery that gives 58 points with probability 60% and 3 points otherwise (3) I am indifferent

r2: Which would you prefer? (1) 36 points for sure (2) a lottery that gives 168 points with probability 20% and 3 points otherwise (3) I am indifferent

End your reply with one JSON object: {"u1": <number>, "r1": <number>, "r2": <number>}"""
    spec = {"u1": {1, 2, 3, 4}, "r1": {1, 2, 3}, "r2": {1, 2, 3}}
    return text, spec
