"""Pre-specified analysis (see ANALYSIS_PLAN.md). Writes analysis.md and
analysis.json into the run directory."""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from .design import rational_cutoff

HUMAN = {"S_pooled": 0.32, "S_ci": (0.29, 0.36), "pay_pv": 36.3, "pay_mpc": 35.5, "fair_mpc_agree": 0.68}
BENCH = 0.448


def load(rdir: Path):
    P, R = [], []
    for f in sorted((rdir / "data").glob("*_participants.jsonl")):
        P += [json.loads(l) for l in open(f)]
    for f in sorted((rdir / "data").glob("*_rounds.jsonl")):
        R += [json.loads(l) for l in open(f)]
    return P, pd.DataFrame(R)


def participant_frame(P, R):
    rows = []
    for p in P:
        a, fl = p["answers"], p["flags"]
        r = R[(R.pid == p["pid"])]
        pv = r[r.phase == "PV"].points.mean()
        mpc = r[r.phase == "MPC"].points.mean()
        sdo_items = [a.get("q3_A"), a.get("q3_D")] + [None if a.get(k) is None else 8 - a[k] for k in ("q3_B", "q3_C", "q3_E", "q3_F")]
        rows.append({
            "pid": p["pid"], "model": p.get("model") or "default", "session": p["session"], "treatment": p["treatment"], "adv": p["adv"],
            "choice": a.get("method_choice"), "choose_mpc": int(a.get("method_choice") == 2),
            "choose_pv": int(a.get("method_choice") == 1),
            "choice_fallback": fl.get("choice_fallback"), "attention_pass": fl.get("attention_pass"),
            "comp_pv_pass": fl.get("comp_pv_pass"), "comp_mpc_pass": fl.get("comp_mpc_pass"),
            "risk_aversion": None if a.get("q4_A") is None else 10 - a["q4_A"],
            "difficulty_mpc": a.get("d8_A"), "difficulty_pv": a.get("d7_A"),
            "simplicity_pref": None if a.get("q8_C") is None else int(a["q8_C"] == 1),
            "sdo": None if any(v is None for v in sdo_items) else float(np.mean(sdo_items)),
            "minority": None if a.get("q10") is None else int(a["q10"] == 1),
            "fair_pv": a.get("d7_C"), "fair_mpc": a.get("d8_C"),
            "understands_commitment": None if a.get("post_u1") is None else int(a["post_u1"] == 2),
            "prefers_sure_majority": None if a.get("post_r1") is None else int(a["post_r1"] == 1),
            "prefers_sure_minority": None if a.get("post_r2") is None else int(a["post_r2"] == 1),
            "pay_pv": pv, "pay_mpc": mpc, "pay_diff": pv - mpc,
            "n_invalid": len(p["invalid"]), "reprompts": p["reprompts"],
            "rational_mpc": int(p["adv"] < rational_cutoff(p["treatment"])),
        })
    d = pd.DataFrame(rows)
    d["included"] = (d.attention_pass == True) & (d.comp_pv_pass == True) & (d.comp_mpc_pass == True) & (d.choice_fallback == False)
    return d


def share_ci(k, n):
    if n == 0:
        return dict(k=0, n=0, S=None, lo=None, hi=None)
    bt = stats.binomtest(k, n)
    ci = bt.proportion_ci(method="exact")
    return dict(k=int(k), n=int(n), S=k / n, lo=ci.low, hi=ci.high,
                p_vs_448_two_sided=stats.binomtest(k, n, BENCH).pvalue,
                p_vs_448_less=stats.binomtest(k, n, BENCH, alternative="less").pvalue,
                p_vs_0_greater=stats.binomtest(k, n, 1e-12, alternative="greater").pvalue if k else 1.0)


def logit(d, xs, cluster=None, fe=None):
    """fe: column whose categories enter as fixed-effect dummies (not standardised, not reported)."""
    import statsmodels.api as sm
    df = d[["choose_pv"] + xs + ([cluster] if cluster else []) + ([fe] if fe and fe != cluster else [])].dropna()
    if len(df) < len(xs) + 5 or df.choose_pv.nunique() < 2:
        return {"error": "not estimable (too few observations or no variation in choice)", "n": len(df)}
    X = df[xs].astype(float)
    sd = X.std(ddof=0)
    if (sd == 0).any():
        return {"error": f"no variation in {list(sd[sd == 0].index)}", "n": len(df)}
    X = sm.add_constant((X - X.mean()) / sd)
    if fe and df[fe].nunique() > 1:
        X = pd.concat([X, pd.get_dummies(df[fe], prefix="fe", drop_first=True).astype(float)], axis=1)
    try:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            m = sm.Logit(df.choose_pv.astype(float), X)
            fit = m.fit(disp=0, cov_type="cluster", cov_kwds={"groups": pd.factorize(df[cluster])[0]}) if cluster else m.fit(disp=0)
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}", "n": len(df)}
    # Analysis plan, Section 4: perfect/quasi-complete separation or non-convergence -> "not estimable".
    y, p = df.choose_pv.astype(float).to_numpy(), fit.predict(X).to_numpy()
    if any("separation" in str(x.message).lower() for x in w) or ((y == 1) & (p > 1 - 1e-6) | (y == 0) & (p < 1e-6)).any():
        return {"error": "not estimable (perfect or quasi-complete separation)", "n": len(df)}
    if not fit.mle_retvals.get("converged", True) or any("converge" in str(x.message).lower() for x in w):
        return {"error": "not estimable (did not converge)", "n": len(df)}
    return {"n": int(fit.nobs), "llf": float(fit.llf),
            "coef": {k: {"b": float(fit.params[k]), "se": float(fit.bse[k]), "p": float(fit.pvalues[k])} for k in xs}}


def ols_full_rating(R, d):
    import statsmodels.formula.api as smf
    r = R[(R.phase == "MPC") & (~R.is_bot) & (R.valid == True)].copy()
    r["rating_full"] = r.ballot.apply(lambda b: b.get("FULL") if isinstance(b, dict) else np.nan)
    r = r.merge(d[["pid", "risk_aversion", "included"]], on="pid")
    r = r[r.included].dropna(subset=["rating_full", "risk_aversion"])
    if len(r) < 10 or r.risk_aversion.std() == 0:
        return {"error": "not estimable (no variation in risk aversion or too few rows)", "n": len(r),
                "mean_full_rating": float(r.rating_full.mean()) if len(r) else None}
    r["risk_z"] = (r.risk_aversion - r.risk_aversion.mean()) / r.risk_aversion.std(ddof=0)
    r["low"] = (r.treatment == "low").astype(int)
    rhs = "risk_z" + (" + low" if r.treatment.nunique() > 1 else "") + (" + C(model)" if "model" in r and r.model.nunique() > 1 else "")
    out = {"formula": "rating_full ~ " + rhs}
    for name, kw in [("ols", {}), ("ols_cluster_pid", {"cov_type": "cluster", "cov_kwds": {"groups": pd.factorize(r.pid)[0]}})]:
        fit = smf.ols("rating_full ~ " + rhs, r).fit(**kw)
        out[name] = {k: {"b": float(fit.params[k]), "se": float(fit.bse[k]), "p": float(fit.pvalues[k])} for k in fit.params.index}
    out["n"] = len(r)
    return out


def usage_summary(rdir):
    tot = dict(calls=0, input=0, cache_write=0, cache_read=0, output=0, cost=0.0, errors=0, refusals=0, max_tokens=0)
    lines = [l for f in sorted((rdir / "api_log").glob("*.jsonl")) for l in open(f)]
    for line in lines:
        rec = json.loads(line)
        if "error" in rec:
            tot["errors"] += 1
            continue
        u = rec["response"].get("usage", {})
        tot["calls"] += 1
        tot["input"] += u.get("input_tokens", 0) or 0
        tot["cache_write"] += u.get("cache_creation_input_tokens", 0) or 0
        tot["cache_read"] += u.get("cache_read_input_tokens", 0) or 0
        tot["output"] += u.get("output_tokens", 0) or 0
        tot["cost"] += rec.get("cost_usd", 0)
        tot["refusals"] += rec["response"].get("stop_reason") == "refusal"
        tot["max_tokens"] += rec["response"].get("stop_reason") == "max_tokens"
    return tot


def per_model(d, R, rdir):
    """Pool runs (OpenRouter): S, exclusions, MaxParC play and cost by model."""
    cost = {}
    for f in sorted((rdir / "api_log").glob("*.jsonl")):
        for line in open(f):
            rec = json.loads(line)
            m = rec.get("model") or "default"
            c = cost.setdefault(m, dict(calls=0, retries=0, cost=0.0, input=0, output=0, reasoning=0,
                                        refusals=0, max_tokens=0, providers={}))
            if "error" in rec:
                c["retries"] += 1
                continue
            u = rec["response"].get("usage", {})
            c["calls"] += 1
            c["cost"] += rec.get("cost_usd", 0) or 0
            c["input"] += (u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0)
            c["output"] += u.get("output_tokens") or 0
            c["reasoning"] += u.get("reasoning_tokens") or 0
            c["refusals"] += rec["response"].get("stop_reason") == "refusal"
            c["max_tokens"] += rec["response"].get("stop_reason") == "max_tokens"
            pr = rec["response"].get("provider") or "?"
            c["providers"][pr] = c["providers"].get(pr, 0) + 1
    h = R[(~R.is_bot) & (R.phase == "MPC")] if "model" in R else R.iloc[0:0]
    out = {}
    for m, g in d.groupby("model"):
        inc = g[g.included]
        b = h[h.model == m] if len(h) else h
        full = b.ballot.apply(lambda x: x.get("FULL", 0) if isinstance(x, dict) else 0) if len(b) else None
        single = b.ballot.apply(lambda x: sum(v > 0 for v in x.values()) == 1 if isinstance(x, dict) else False) if len(b) else None
        out[m] = {"n": len(g), "included": len(inc),
                  "attention_fail": int((g.attention_pass != True).sum()),
                  "comp_pv_fail": int((g.comp_pv_pass != True).sum()),
                  "comp_mpc_fail": int((g.comp_mpc_pass != True).sum()),
                  "choice_invalid": int((g.choice_fallback == True).sum()),
                  "reprompts": int(g.reprompts.sum()), "invalid_after_reprompt": int(g.n_invalid.sum()),
                  "S_included": share_ci(int(inc.choose_mpc.sum()), len(inc)) if len(inc) else None,
                  "S_all": share_ci(int(g.choose_mpc.sum()), len(g)),
                  "understands_commitment": float(g.understands_commitment.mean()) if g.understands_commitment.notna().any() else None,
                  "prefers_sure_majority": float(g.prefers_sure_majority.mean()) if g.prefers_sure_majority.notna().any() else None,
                  "prefers_sure_minority": float(g.prefers_sure_minority.mean()) if g.prefers_sure_minority.notna().any() else None,
                  "MPC_ballots": len(b),
                  "MPC_share_FULL_positive": float((full > 0).mean()) if len(b) else None,
                  "MPC_mean_FULL_rating": float(full.mean()) if len(b) else None,
                  "MPC_share_single_option": float(single.mean()) if len(b) else None,
                  "usage": cost.get(m)}
        if out[m]["usage"]:
            out[m]["usage"]["cost_per_participant"] = out[m]["usage"]["cost"] / len(g)
    return out


def study2(d, inc, models):
    """Study 2 (pool) analyses per ANALYSIS_PLAN_STUDY2.md Sections 2-3."""
    out = {}
    sm_ = inc.groupby("model").choose_mpc.agg(["mean", "sum", "count"])
    k = len(sm_)
    if k > 1:
        m, se = sm_["mean"].mean(), sm_["mean"].std(ddof=1) / np.sqrt(k)
        t = stats.t.ppf(0.975, k - 1)
        out["pooled_across_models_t"] = {"mean_of_model_shares": float(m), "lo": float(m - t * se), "hi": float(m + t * se), "k": k}
        tab = np.array([sm_["sum"], sm_["count"] - sm_["sum"]]).T
        chi2, p, dof, exp = stats.chi2_contingency(tab)
        res = {"chi2": float(chi2), "dof": int(dof), "p": float(p), "min_expected": float(exp.min())}
        if exp.min() < 5:  # Monte-Carlo p-value with fixed margins
            rng = np.random.default_rng(0)
            pool = np.repeat([1, 0], [int(tab[:, 0].sum()), int(tab[:, 1].sum())])
            sims = []
            for _ in range(10000):
                rng.shuffle(pool)
                parts = np.split(pool, np.cumsum(sm_["count"].to_numpy())[:-1])
                st = np.array([[x.sum(), len(x) - x.sum()] for x in parts])
                sims.append(stats.chi2_contingency(st)[0] if st[:, 0].sum() and st[:, 1].sum() else 0)
            res["p_monte_carlo"] = float(np.mean(np.array(sims) >= chi2))
        out["heterogeneity_chi2"] = res
    out["logit_choose_PV_modelFE_cluster_session"] = {kk: logit(inc, v, "session", fe="model") for kk, v in models.items()}
    out["logit_choose_PV_per_model"] = {mm: {kk: logit(g, v) for kk, v in models.items()} for mm, g in inc.groupby("model")}
    return out


def analyze(rdir: Path):
    rdir = Path(rdir)
    P, R = load(rdir)
    if not P:
        print("no data")
        return
    d = participant_frame(P, R)
    res = {"n_participants": len(d), "n_included": int(d.included.sum())}
    res["exclusions"] = {
        "attention_fail": int((d.attention_pass != True).sum()),
        "comp_pv_fail": int((d.comp_pv_pass != True).sum()),
        "comp_mpc_fail": int((d.comp_mpc_pass != True).sum()),
        "choice_invalid": int((d.choice_fallback == True).sum()),
    }
    # primary
    prim = {}
    for label, sub in [("high", d[d.treatment == "high"]), ("low", d[d.treatment == "low"]), ("pooled", d)]:
        inc = sub[sub.included]
        prim[label] = {"included": share_ci(int(inc.choose_mpc.sum()), len(inc)),
                       "all": share_ci(int(sub.choose_mpc.sum()), len(sub)),
                       "rational_benchmark_formula": None if label == "pooled" else rational_cutoff(label),
                       "rational_benchmark_sample": float(inc.rational_mpc.mean()) if len(inc) else None}
    res["S"] = prim
    inc = d[d.included]
    tab = [[int(((inc.treatment == t) & (inc.choose_mpc == c)).sum()) for c in (1, 0)] for t in ("high", "low")]
    res["fisher_high_vs_low"] = {"table_[high,low]x[MPC,PV]": tab,
                                 "p_two_sided": stats.fisher_exact(tab)[1] if min(map(sum, tab)) else None,
                                 "p_high_greater (H2a)": stats.fisher_exact(tab, alternative="greater")[1] if min(map(sum, tab)) else None,
                                 "p_low_greater (H2b)": stats.fisher_exact(tab, alternative="less")[1] if min(map(sum, tab)) else None}
    models = {
        "(1) risk": ["risk_aversion"], "(2) difficulty": ["difficulty_mpc"], "(3) advantage": ["adv"],
        "(4) adv + pay diff": ["adv", "pay_diff"], "(5) adv + PV pay + MPC pay": ["adv", "pay_pv", "pay_mpc"],
        "(6) all": ["risk_aversion", "difficulty_mpc", "adv", "pay_pv", "pay_mpc"],
        "H1b simplicity": ["simplicity_pref"], "H2c SDO": ["sdo"], "H3 minority": ["minority"],
    }
    if d.understands_commitment.notna().any():  # Study 2 post-debrief items
        models.update({"S2 understanding": ["understands_commitment"],
                       "S2 sure-thing preference": ["prefers_sure_majority", "prefers_sure_minority"],
                       "S2 understanding + sure-thing + adv": ["understands_commitment", "prefers_sure_majority",
                                                               "prefers_sure_minority", "adv"]})
    res["logit_choose_PV"] = {k: logit(inc, v) for k, v in models.items()}
    res["logit_choose_PV_cluster_session"] = {k: logit(inc, v, "session") for k, v in models.items()}
    res["tableS3_full_rating"] = ols_full_rating(R, d)
    # descriptives
    h = R[~R.is_bot]
    mpc = R[R.phase == "MPC"].drop_duplicates("group")
    res["descriptives"] = {
        "mean_points_PV_rounds": float(h[h.phase == "PV"].points.mean()),
        "mean_points_MPC_rounds": float(h[h.phase == "MPC"].points.mean()),
        "MPC_full_compromise_win_rate": float((mpc.winner == "FULL").mean()) if len(mpc) else None,
        "MPC_mean_P(FULL)": float(mpc.lottery.apply(lambda l: l["FULL"]).mean()) if len(mpc) else None,
        "PV_majority_option_win_rate": float((R[R.phase == "PV"].drop_duplicates("group").winner == "MAJ").mean()),
        "PV_vote_by_role": {int(r): g.ballot.fillna("abstain").value_counts(normalize=True).round(3).to_dict()
                            for r, g in h[h.phase == "PV"].groupby("role")},
        "fair_MPC_agree_share": float((d.fair_mpc <= 2).mean()),
        "fair_PV_agree_share": float((d.fair_pv <= 2).mean()),
        "attitude_variation_sd": {k: float(d[k].std()) for k in ["risk_aversion", "difficulty_mpc", "sdo", "simplicity_pref", "minority"]},
    }
    inv = {}
    for p in P:
        for e in p["invalid"]:
            step = "".join(c for c in e["step"] if not c.isdigit())
            inv[step] = inv.get(step, 0) + 1
    res["invalid_after_reprompt_by_step"] = inv
    res["reprompts_total"] = int(d.reprompts.sum())
    res["usage"] = usage_summary(rdir)
    if d.model.nunique() > 1 or (d.model != "default").any():
        res["by_model"] = per_model(d, R, rdir)
        res["study2"] = study2(d, inc, models)
    (rdir / "analysis.json").write_text(json.dumps(res, indent=1, default=float))
    d.to_csv(rdir / "participants.csv", index=False)
    write_md(rdir, res)
    print((rdir / "analysis.md").read_text())


def _pct(x):
    return "n/a" if x is None else f"{100 * x:.1f}%"


def write_md(rdir, res):
    L = [f"# Results: {rdir.name}", "",
         f"Participants: {res['n_participants']}, included in primary analysis: {res['n_included']}", "",
         "## Primary outcome: share S choosing MaxParC (Method 2)", "",
         "| | S (included) | 95% CI (Clopper-Pearson) | n | S (all) | rational (formula) | rational (this sample) | human (paper) |",
         "|---|---|---|---|---|---|---|---|"]
    for t in ("high", "low", "pooled"):
        s, a = res["S"][t]["included"], res["S"][t]["all"]
        hum = f"{_pct(HUMAN['S_pooled'])} [29%, 36%]" if t == "pooled" else "not reported"
        L.append(f"| {t} | {_pct(s['S'])} | [{_pct(s['lo'])}, {_pct(s['hi'])}] | {s['n']} | {_pct(a['S'])} | "
                 f"{_pct(res['S'][t]['rational_benchmark_formula']) if t != 'pooled' else '44.8% (paper)'} | {_pct(res['S'][t]['rational_benchmark_sample'])} | {hum} |")
    p = res["S"]["pooled"]["included"]
    if p["n"]:
        L += ["", f"Exact binomial test vs 44.8% (pooled, included): two-sided p = {p['p_vs_448_two_sided']:.3g}; one-sided (S < 44.8%, H1a) p = {p['p_vs_448_less']:.3g}."]
    f = res["fisher_high_vs_low"]
    L += ["", f"Fisher exact test high vs low: {f}", "", "## Exclusions", "", json.dumps(res["exclusions"]), "",
          "## Logit: choose PV (standardised predictors)", "```", json.dumps(res["logit_choose_PV"], indent=1), "```",
          "## Table S3 analogue: rating of the full-compromise option (MaxParC rounds)", "```", json.dumps(res["tableS3_full_rating"], indent=1), "```",
          "## Descriptives", "```", json.dumps(res["descriptives"], indent=1, default=str), "```",
          "## Invalid answers", f"Re-prompts: {res['reprompts_total']}; still invalid after re-prompt, by step: {res['invalid_after_reprompt_by_step']}", "",
          "## API usage", "```", json.dumps(res["usage"], indent=1), "```"]
    if res.get("study2"):
        s2 = res["study2"]
        L += ["", "## Study 2 (pool)", "", "Pooled across models (t-interval over model shares): " + json.dumps(s2.get("pooled_across_models_t")),
              "", "Heterogeneity across models: " + json.dumps(s2.get("heterogeneity_chi2")), "",
              "Logit choose PV, model fixed effects, SE clustered by session:", "```",
              json.dumps(s2["logit_choose_PV_modelFE_cluster_session"], indent=1), "```"]
    if res.get("by_model"):
        L += ["", "## By model", "",
              "| model | n | incl. | S incl. [95% CI] | S all | fails att/PV/MPC/choice | re-prompts | ballots FULL>0 | single-option ballots | cost/participant | output tok/participant |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        for m, r in res["by_model"].items():
            s = r["S_included"]
            u = r["usage"] or {}
            L.append(f"| {m} | {r['n']} | {r['included']} | "
                     + (f"{_pct(s['S'])} [{_pct(s['lo'])}, {_pct(s['hi'])}]" if s else "n/a")
                     + f" | {_pct(r['S_all']['S'])} | {r['attention_fail']}/{r['comp_pv_fail']}/{r['comp_mpc_fail']}/{r['choice_invalid']}"
                     + f" | {r['reprompts']} | {_pct(r['MPC_share_FULL_positive'])} | {_pct(r['MPC_share_single_option'])}"
                     + f" | ${u.get('cost_per_participant', 0):.4f} | {u.get('output', 0) // max(r['n'], 1)} |")
    (rdir / "analysis.md").write_text("\n".join(L) + "\n")
