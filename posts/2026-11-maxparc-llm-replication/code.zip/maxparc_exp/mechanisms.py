"""Group decision methods used in the experiment.

MaxParC follows Supplement 2.2.2.10 of Heitzig, Simmons & Constantino (2025)
exactly, with ratings rescaled from [0, 100] to [0, 1]:

  A(x)  = largest set A of voters with |A|/N + beta_ix > 1 for all i in A
  s(x)  = |A(x)| + sum_i beta_ix / N
  A_i   = {x : i in A(x)},  W_i = argmax_{y in A_i} s(y)
  A_0   = voters approving nothing (abstainers)
  If A_0 != E:  M(x) = sum_{i : x in W_i} (1/|W_i|) / (N - |A_0|)
  else:         M = uniform on argmax_x s(x)

Exact rational arithmetic (fractions.Fraction) is used throughout so that
ties are detected exactly.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Dict, Hashable, List, Optional, Sequence

Option = Hashable


def _frac(v) -> Fraction:
    """Exact conversion; floats go via their decimal repr so that 0.2 == 1/5
    (binary float 0.2 is slightly above 1/5 and would flip the strict '>')."""
    if isinstance(v, Fraction):
        return v
    if isinstance(v, float):
        return Fraction(repr(v))
    return Fraction(v)


def approval_set(ratings_of_x: Sequence[Fraction]) -> List[int]:
    """Largest set A with |A|/N + r_i > 1 for all i in A (Granovetter cutoff).

    If A is feasible and r_j >= min_{i in A} r_i then A + {j} is feasible too,
    so the maximal feasible set is an upper set {i : r_i >= c}. We take the
    largest such upper set that satisfies the condition.
    """
    n = len(ratings_of_x)
    order = sorted(range(n), key=lambda i: ratings_of_x[i], reverse=True)
    best = 0
    # candidate sizes are the sizes of upper sets; ties must be included together
    k = 0
    while k < n:
        # extend k to include all voters tied with order[k]
        r = ratings_of_x[order[k]]
        j = k
        while j < n and ratings_of_x[order[j]] == r:
            j += 1
        size = j
        if Fraction(size, n) + r > 1:  # r is the minimum rating in this upper set
            best = size
        k = j
    return sorted(order[:best])


def maxparc(ballots: Sequence[Dict[Option, float]], options: Sequence[Option]) -> Dict[Option, Fraction]:
    """MaxParC lottery. `ballots[i][x]` is voter i's rating of x in [0, 1]."""
    n = len(ballots)
    beta = [{x: _frac(b.get(x, 0)) for x in options} for b in ballots]
    for b in beta:
        for v in b.values():
            if not (0 <= v <= 1):
                raise ValueError("ratings must lie in [0, 1]")
    A = {x: set(approval_set([beta[i][x] for i in range(n)])) for x in options}
    s = {x: len(A[x]) + sum(beta[i][x] for i in range(n)) / n for x in options}
    p = {x: Fraction(0) for x in options}
    abstainers = [i for i in range(n) if not any(i in A[x] for x in options)]
    if len(abstainers) < n:
        denom = n - len(abstainers)
        for i in range(n):
            Ai = [x for x in options if i in A[x]]
            if not Ai:
                continue
            m = max(s[x] for x in Ai)
            Wi = [x for x in Ai if s[x] == m]
            for x in Wi:
                p[x] += Fraction(1, len(Wi)) / denom
    else:
        m = max(s.values())
        W = [x for x in options if s[x] == m]
        for x in W:
            p[x] = Fraction(1, len(W))
    return p


def maxparc_details(ballots, options):
    """Lottery plus approval sets and scores (for feedback to participants)."""
    n = len(ballots)
    beta = [{x: _frac(b.get(x, 0)) for x in options} for b in ballots]
    A = {x: approval_set([beta[i][x] for i in range(n)]) for x in options}
    s = {x: len(A[x]) + sum(beta[i][x] for i in range(n)) / n for x in options}
    return maxparc(ballots, options), A, s


def plurality(votes: Sequence[Optional[Option]], options: Sequence[Option]) -> Dict[Option, Fraction]:
    """Plurality voting with abstention (vote None). Uniform tie-break among
    plurality winners; if nobody votes, all options tie."""
    counts = {x: 0 for x in options}
    for v in votes:
        if v is not None:
            counts[v] += 1
    m = max(counts.values())
    W = [x for x in options if counts[x] == m]
    return {x: (Fraction(1, len(W)) if x in W else Fraction(0)) for x in options}
