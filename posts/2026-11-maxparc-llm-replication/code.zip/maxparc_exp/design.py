"""Payoff design from Supplement 2.4.1, Tables S1 (high inequality) and S2 (low).

Option keys (not shown to participants):
  MAJ  = majority option (A in the tables)
  MIN4 = minority option for voter 4 (B)
  MIN5 = minority option for voter 5 (C)
  PART = partial compromise (D)
  FULL = full compromise (E)
Roles 1..5: role 1 = highest advantage value in the group.
Each cell is an inclusive integer interval; every cell is drawn independently and
uniformly each round (assumption: the paper says only "chosen randomly from the
interval of integer numbers shown").
"""
from math import comb

OPTION_KEYS = ["MAJ", "MIN4", "MIN5", "PART", "FULL"]
L = (2, 5)
TABLES = {
    "high": {
        "MAJ": [(73, 75), (57, 59), (41, 43), L, L],
        "MIN4": [L, L, L, (156, 176), L],
        "MIN5": [L, L, L, L, (156, 176)],
        "PART": [(61, 63), (49, 51), (37, 39), (25, 27), L],
        "FULL": [(59, 61), (47, 49), (35, 37), (23, 25), (11, 13)],
    },
    "low": {
        "MAJ": [(57, 59)] * 3 + [L, L],
        "MIN4": [L, L, L, (165, 167), L],
        "MIN5": [L, L, L, L, (165, 167)],
        "PART": [(43, 45)] * 4 + [L],
        "FULL": [(35, 37)] * 5,
    },
}


def draw_payoffs(rng, treatment):
    """dict option_key -> list of 5 ints (index = role-1)."""
    return {k: [rng.randint(lo, hi) for (lo, hi) in TABLES[treatment][k]] for k in OPTION_KEYS}


def favourite(role, payoffs=None, treatment=None):
    """Self-interested favourite option of a role (by payoff)."""
    if payoffs is None:
        payoffs = {k: [(lo + hi) / 2 for lo, hi in TABLES[treatment][k]] for k in OPTION_KEYS}
    return max(OPTION_KEYS, key=lambda k: payoffs[k][role - 1])


def rank_probs(a):
    """P(role = r | own advantage a), 4 other advantages iid U(0,1)."""
    return [comb(4, k) * (1 - a) ** k * a ** (4 - k) for k in range(5)]


def rational_cutoff(treatment):
    """Advantage value a* below which a self-interested, risk-neutral participant
    prefers MaxParC (equilibrium: FULL for sure) to PV (equilibrium: MAJ wins),
    using interval midpoints. Under a ~ U(0,1) the rational share choosing MaxParC is a*."""
    mid = {k: [(lo + hi) / 2 for lo, hi in TABLES[treatment][k]] for k in OPTION_KEYS}
    f = lambda a: sum(p * (mid["FULL"][r] - mid["MAJ"][r]) for r, p in enumerate(rank_probs(a)))
    lo, hi = 1e-12, 1 - 1e-12
    for _ in range(200):
        m = (lo + hi) / 2
        if f(lo) * f(m) > 0:
            lo = m
        else:
            hi = m
    return (lo + hi) / 2


def prefers_maxparc(a, treatment):
    return a < rational_cutoff(treatment)
