"""Offline stand-in for the API, used only for pipeline tests (--fake).
Produces random valid answers and, on purpose, ~5% unparseable ones so the
re-prompt and fallback paths are exercised. Never used for real data."""
import hashlib, json, random, re


def fake_response(key, messages):
    rng = random.Random(hashlib.sha256(key.encode()).hexdigest())
    prompt = messages[-1]["content"]
    if rng.random() < 0.05:
        txt = "I am not sure."
    elif '"vote"' in prompt:
        txt = "Thinking... " + json.dumps({"vote": rng.choice(list("ABCDE") + [None])})
    elif '"ratings"' in prompt:
        txt = json.dumps({"ratings": {L: rng.randint(0, 100) for L in "ABCDE"}})
    elif '"method"' in prompt:
        txt = json.dumps({"method": rng.choice([1, 2])})
    elif '"m1"' in prompt:
        txt = json.dumps({"m1": "no", "m2": 100, "m3": rng.choice([40, 50])})
    elif '"c1"' in prompt:
        txt = json.dumps({"c1": "A", "c2": "50%"})
    else:  # questionnaires
        keys = re.findall(r'"(\w+)": <number', prompt)
        ans = {k: 1 for k in keys}
        if "q3_X" in ans:
            ans["q3_X"] = 4
        txt = "Answers: " + json.dumps(ans)
    return {"id": "fake", "model": "fake", "content": [{"type": "text", "text": txt}],
            "stop_reason": "end_turn", "stop_details": None,
            "usage": {"input_tokens": 0, "output_tokens": 0}}
