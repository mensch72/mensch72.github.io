"""Session flow: questionnaire -> 8 PV rounds -> 8 MaxParC rounds -> free choice
+ 2 rounds -> debriefing. All participants of a session advance in lockstep;
groups of five are re-drawn at random from the session pool every round.

Determinism: all randomness is drawn from one per-session RNG in the
orchestrating coroutine, in a fixed order, never inside concurrent tasks. Given
the logged API responses, a session therefore replays exactly, which is how
interrupted runs are resumed.
"""
from __future__ import annotations

import asyncio
import json
import random
import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, List, Optional

from . import prompts as P
from .design import OPTION_KEYS, draw_payoffs, favourite
from .mechanisms import maxparc_details, plurality

LETTERS = list("ABCDE")
PERSON = ["person two", "person three", "person four", "person five"]


# ---------------------------------------------------------------- JSON extraction / validation
def last_json_object(text: str) -> Optional[dict]:
    """The top-level JSON object that ends last in the text (outermost if nested)."""
    dec = json.JSONDecoder()
    best = None  # (end, -start, obj)
    for m in re.finditer(r"\{", text):
        try:
            obj, end = dec.raw_decode(text, m.start())
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and (best is None or (end, -m.start()) > best[:2]):
            best = (end, -m.start(), obj)
    return None if best is None else best[2]


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        try:
            return float(v.strip().rstrip("%"))
        except ValueError:
            return None
    return None


def validate_spec(obj, spec):
    """Strict validation; returns (value_dict, error). No silent repair: values must
    already have the right type (numeric strings are accepted for numbers only in
    comprehension answers, where the question asks for a number)."""
    if obj is None:
        return None, "no JSON object found at the end of your reply"
    out, errs = {}, []
    for k, s in spec.items():
        if k not in obj:
            errs.append(f"missing key {k!r}")
            continue
        v = obj[k]
        if isinstance(s, set):
            if isinstance(v, bool) or not isinstance(v, int) or v not in s:
                errs.append(f"{k!r} must be one of {sorted(s)}")
            else:
                out[k] = v
        elif s[0] == "int":
            if isinstance(v, bool) or not isinstance(v, int) or not (s[1] <= v <= s[2]):
                errs.append(f"{k!r} must be a whole number from {s[1]} to {s[2]}")
            else:
                out[k] = v
        elif s[0] == "nullable15":
            if v is None or (isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 5):
                out[k] = v
            else:
                errs.append(f"{k!r} must be 1-5 or null")
        elif s[0] == "letter":
            if isinstance(v, str) and v.strip().upper() in LETTERS:
                out[k] = v.strip().upper()
            else:
                errs.append(f"{k!r} must be a letter A-E")
        elif s[0] == "yesno":
            if isinstance(v, str) and v.strip().lower() in ("yes", "no"):
                out[k] = v.strip().lower()
            else:
                errs.append(f"{k!r} must be \"yes\" or \"no\"")
        elif s[0] == "num":
            n = _num(v)
            if n is None or not (s[1] <= n <= s[2]):
                errs.append(f"{k!r} must be a number from {s[1]} to {s[2]}")
            else:
                out[k] = n
    return (out, None) if not errs else (None, "; ".join(errs))


def v_vote(obj):
    if obj is None or "vote" not in obj:
        return None, 'expected {"vote": "<letter A-E>"} or {"vote": null}'
    v = obj["vote"]
    if v is None:
        return {"vote": None}, None
    if isinstance(v, str) and v.strip().upper() in LETTERS:
        return {"vote": v.strip().upper()}, None
    return None, '"vote" must be one letter A-E or null'


def v_ratings(obj):
    if obj is None or not isinstance(obj.get("ratings"), dict):
        return None, 'expected {"ratings": {"A": <r>, ..., "E": <r>}}'
    r = obj["ratings"]
    out = {}
    for L in LETTERS:
        v = r.get(L)
        if isinstance(v, bool) or not isinstance(v, int) or not (0 <= v <= 100):
            return None, f"rating for {L} must be a whole number from 0 to 100 (got {v!r})"
        out[L] = v
    if set(r) - set(LETTERS):
        return None, f"unexpected keys {sorted(set(r) - set(LETTERS))}"
    return {"ratings": out}, None


def v_method(obj):
    if obj is None or obj.get("method") not in (1, 2) or isinstance(obj.get("method"), bool):
        return None, 'expected {"method": 1} or {"method": 2}'
    return {"method": obj["method"]}, None


# ---------------------------------------------------------------- participants
@dataclass
class Participant:
    pid: str
    adv: float
    is_bot: bool = False
    messages: List[dict] = field(default_factory=list)
    pending: List[str] = field(default_factory=list)  # feedback to prepend to next prompt
    last_logged_len: int = 0
    answers: Dict[str, Any] = field(default_factory=dict)
    flags: Dict[str, Any] = field(default_factory=dict)
    invalid: List[dict] = field(default_factory=list)
    reprompts: int = 0
    model: Optional[str] = None  # OpenRouter model of this participant (None: the run's default model)


def response_text(resp) -> str:
    return "\n".join(b.get("text", "") for b in resp["content"] if b.get("type") == "text")


class Session:
    def __init__(self, llm, sid: str, treatment: str, n: int, seed: int, out, models=None, post_questions=False):
        assert n % 5 == 0
        self.llm, self.sid, self.treatment, self.n, self.out = llm, sid, treatment, n, out
        self.rng = random.Random(seed)
        self.post_questions = post_questions
        self.seed = seed
        self.people = [Participant(f"{sid}-p{i:03d}", self.rng.random()) for i in range(n)]
        # Model pool: participant i gets models[i % len(models)] (balanced; uses no random numbers,
        # so payoffs and groupings depend on the seed exactly as without a pool).
        for i, p in enumerate(self.people):
            p.model = models[i % len(models)] if models else None
        self.round_rows: List[dict] = []
        self.bot_count = 0

    # ------------------------------------------------ one decision of one participant
    async def ask(self, p: Participant, step: str, text: str, validator, fmt_hint: str):
        if p.pending:
            text = "\n\n".join(p.pending + [text])
            p.pending = []
        p.messages.append({"role": "user", "content": text})
        raw_attempts = []
        for attempt in (0, 1):
            new = p.messages[p.last_logged_len:]
            meta = {"session": self.sid, "pid": p.pid, "step": step, "attempt": attempt}
            resp = await self.llm.call(f"{p.pid}|{step}|{attempt}", meta, p.messages, new, model=p.model)
            content = resp["content"] or [{"type": "text", "text": "(empty response)"}]
            p.messages.append({"role": "assistant", "content": content})
            p.last_logged_len = len(p.messages)
            txt = response_text(resp)
            raw_attempts.append({"text": txt, "stop_reason": resp["stop_reason"]})
            if resp["stop_reason"] in ("refusal", "max_tokens"):
                val, err = None, f"stop_reason={resp['stop_reason']}"
            else:
                val, err = validator(last_json_object(txt))
            if val is not None:
                return val, {"valid": True, "attempts": attempt + 1, "raw": raw_attempts}
            if attempt == 0:
                p.reprompts += 1
                p.messages.append({"role": "user", "content":
                    f"Your answer could not be processed ({err}). Please answer again, ending your reply with one JSON object. {fmt_hint}"})
        p.invalid.append({"step": step, "error": err})
        return None, {"valid": False, "attempts": 2, "raw": raw_attempts, "error": err}

    async def gather(self, jobs):
        return await asyncio.gather(*jobs)

    # ------------------------------------------------ phases
    async def questionnaire(self):
        texts = [P.initial_questionnaire(self.rng) for _ in self.people]
        res = await self.gather([self.ask(p, "q_initial", t, lambda o, s=s: validate_spec(o, s),
                                          "Include every requested key.")
                                 for p, (t, s, _) in zip(self.people, texts)])
        for p, (val, info), (_, _, meta) in zip(self.people, res, texts):
            p.answers.update(val or {})
            p.answers["q_order"] = meta
            p.flags["q_initial_valid"] = info["valid"]
            p.flags["attention_pass"] = bool(val) and val.get("q3_X") == 4

    async def instructions(self, step, text, comp):
        res = await self.gather([self.ask(p, step, text, lambda o: validate_spec(o, comp["spec"]),
                                          comp["text"].splitlines()[-1]) for p in self.people])
        for p, (val, info) in zip(self.people, res):
            ok = bool(val) and all(
                (val[k] == a if isinstance(a, str) else abs(val[k] - a) < 1e-9) for k, a in comp["answers"].items())
            p.flags[f"{step}_valid"] = info["valid"]
            p.flags[f"{step}_pass"] = ok
            p.answers[step] = val
            p.pending.append(P.comprehension_feedback(comp["answers"], val or {}, ok))

    def make_bot(self):
        self.bot_count += 1
        return Participant(f"{self.sid}-bot{self.bot_count:03d}", self.rng.random(), is_bot=True)

    async def play_round(self, groups, method: str, phase: str, rnd: int, label: str):
        await self.play_rounds([(groups, method, phase)], rnd, label)

    async def play_rounds(self, games, rnd: int, label: str):
        """games: list of (groups, method, phase); groups = lists of 5 Participants,
        method 'PV' or 'MPC'. All API calls of all games are gathered at once; all
        randomness is drawn before/after the gather in a fixed order (replayable)."""
        setups = []
        for groups, method, phase in games:
          for gi, g in enumerate(groups):
            order = sorted(g, key=lambda q: -q.adv)
            role = {q.pid: order.index(q) + 1 for q in g}
            pay = draw_payoffs(self.rng, self.treatment)
            views = {}
            for q in g:
                perm = OPTION_KEYS[:]
                self.rng.shuffle(perm)  # display label i -> option key
                others = [o for o in g if o is not q]
                self.rng.shuffle(others)
                views[q.pid] = (perm, others)
            setups.append((g, role, pay, views, method, phase, gi))
        jobs, idx = [], []
        for si, (g, role, pay, views, method, phase, gi) in enumerate(setups):
            nbots = sum(q.is_bot for q in g)
            for q in g:
                if q.is_bot:
                    continue
                perm, others = views[q.pid]
                hdr = f"Round {label} ({'Method 1' if method == 'PV' else 'Method 2'})."
                if nbots:
                    hdr += f" Note: your group in this round includes {nbots} simulated participant(s)."
                rows = ["Option | you | " + " | ".join(PERSON)]
                for L, k in zip(LETTERS, perm):
                    rows.append(f"{L} | {pay[k][role[q.pid]-1]} | " + " | ".join(str(pay[k][role[o.pid]-1]) for o in others))
                text = hdr + "\nBonus points for each group member if the option is chosen:\n" + "\n".join(rows) + "\n\n" + (P.PV_REQUEST if method == "PV" else P.MPC_REQUEST)
                v = v_vote if method == "PV" else v_ratings
                jobs.append(self.ask(q, f"{phase}{rnd}", text, v, P.PV_REQUEST if method == "PV" else P.MPC_REQUEST))
                idx.append((si, q))
        results = await self.gather(jobs)
        by = {q.pid: r for (si, q), r in zip(idx, results)}
        for si, (g, role, pay, views, method, phase, gi) in enumerate(setups):
            ballots, fallback = {}, {}
            for q in g:
                perm, _ = views[q.pid]
                if q.is_bot:  # rational bot: favourite (and FULL at 20 under MaxParC)
                    fav = favourite(role[q.pid], pay)
                    ballots[q.pid] = fav if method == "PV" else {k: (100 if k == fav else 20 if k == "FULL" else 0) for k in OPTION_KEYS}
                    continue
                val, info = by[q.pid]
                if val is None:  # pre-registered fallback, flagged
                    fallback[q.pid] = True
                    if method == "PV":
                        ballots[q.pid] = self.rng.choice(OPTION_KEYS)
                    else:
                        ballots[q.pid] = {k: 0 for k in OPTION_KEYS}
                elif method == "PV":
                    ballots[q.pid] = None if val["vote"] is None else perm[LETTERS.index(val["vote"])]
                else:
                    ballots[q.pid] = {perm[LETTERS.index(L)]: r for L, r in val["ratings"].items()}
            if method == "PV":
                lot = plurality([ballots[q.pid] for q in g], OPTION_KEYS)
                counts = {k: sum(ballots[q.pid] == k for q in g) for k in OPTION_KEYS}
                approvals = None
            else:
                lot, A, s = maxparc_details([{k: Fraction(v, 100) for k, v in ballots[q.pid].items()} for q in g], OPTION_KEYS)
                approvals = {k: [g[i].pid for i in A[k]] for k in OPTION_KEYS}
            u = self.rng.random()
            acc, winner = Fraction(0), OPTION_KEYS[-1]
            for k in OPTION_KEYS:
                acc += lot[k]
                if lot[k] > 0 and u < acc:
                    winner = k
                    break
            for q in g:
                perm, _ = views[q.pid]
                pts = pay[winner][role[q.pid] - 1]
                q.answers.setdefault("points", []).append(pts)
                lab = {k: LETTERS[perm.index(k)] for k in OPTION_KEYS}
                if not q.is_bot:
                    if method == "PV":
                        res = "Votes: " + ", ".join(f"{L} {counts[perm[i]]}" for i, L in enumerate(LETTERS)) + f" (abstentions: {sum(ballots[o.pid] is None for o in g)})."
                    else:
                        res = ("Approval scores (number of members approving): " + ", ".join(f"{L} {len(approvals[perm[i]])}" for i, L in enumerate(LETTERS))
                               + ". You were counted as approving: " + (", ".join(L for i, L in enumerate(LETTERS) if q.pid in approvals[perm[i]]) or "nothing (you abstained)") + ".")
                    probs = ", ".join(f"{L} {float(lot[perm[i]])*100:.0f}%" for i, L in enumerate(LETTERS) if lot[perm[i]] > 0)
                    total = sum(q.answers["points"])
                    q.pending.append(f"Result of round {label}: {res} Winning probabilities: {probs}. Chosen option: {lab[winner]}. You earn {pts} points in this round. Your total so far: {total} points.")
                val, info = by.get(q.pid, (None, {"valid": None, "attempts": 0, "raw": []}))
                self.round_rows.append({
                    "session": self.sid, "treatment": self.treatment, "pid": q.pid, "is_bot": q.is_bot,
                    "model": "bot" if q.is_bot else q.model,
                    "adv": q.adv, "phase": phase, "round": rnd, "method": method, "group": f"{self.sid}-{phase}{rnd}-g{gi}",
                    "group_pids": [o.pid for o in g], "role": role[q.pid], "display_order": perm,
                    "payoffs": pay, "ballot": ballots[q.pid], "raw_answer": val, "valid": info["valid"],
                    "attempts": info["attempts"], "fallback": fallback.get(q.pid, False),
                    "lottery": {k: float(v) for k, v in lot.items()}, "winner": winner, "points": pts,
                    "approvals": approvals, "raw_text": info["raw"],
                })

    def random_groups(self, pool):
        pool = pool[:]
        self.rng.shuffle(pool)
        return [pool[i:i + 5] for i in range(0, len(pool), 5)]

    async def run(self):
        await self.questionnaire()
        await self.instructions("comp_pv", P.GAME_INTRO + "\n\n" + P.PV_RULES + "\n\n" + P.PV_COMPREHENSION["text"], P.PV_COMPREHENSION)
        for r in range(1, 9):
            await self.play_round(self.random_groups(self.people), "PV", "PV", r, f"{r} of 18")
        await self.instructions("comp_mpc", "Part 3: The next 8 rounds use a different group decision method.\n\n" + P.MPC_RULES + "\n\n" + P.MPC_COMPREHENSION["text"], P.MPC_COMPREHENSION)
        for r in range(1, 9):
            await self.play_round(self.random_groups(self.people), "MPC", "MPC", r, f"{8 + r} of 18")
        res = await self.gather([self.ask(p, "choice", P.FREE_CHOICE, v_method, '{"method": 1} or {"method": 2}') for p in self.people])
        for p, (val, info) in zip(self.people, res):
            p.flags["choice_valid"] = info["valid"]
            p.answers["choice_raw"] = info["raw"]
            if val is None:
                p.answers["method_choice"] = self.rng.choice([1, 2])
                p.flags["choice_fallback"] = True
            else:
                p.answers["method_choice"] = val["method"]
                p.flags["choice_fallback"] = False
        pools = {m: [p for p in self.people if p.answers["method_choice"] == m] for m in (1, 2)}
        for r in range(1, 3):
            groups_by = {}
            for m, pool in pools.items():
                if not pool:
                    continue
                gs = self.random_groups(pool)
                if len(gs[-1]) < 5:
                    gs[-1] = gs[-1] + [self.make_bot() for _ in range(5 - len(gs[-1]))]
                groups_by[m] = gs
            # both methods' groups are played in the same round (one gather)
            await self.play_rounds([(gs, "PV" if m == 1 else "MPC", f"FC{m}_") for m, gs in groups_by.items()],
                                   r, f"{16 + r} of 18")
        text, spec = P.debrief()
        res = await self.gather([self.ask(p, "debrief", text, lambda o: validate_spec(o, spec), "Include every requested key.") for p in self.people])
        for p, (val, info) in zip(self.people, res):
            p.answers.update(val or {})
            p.flags["debrief_valid"] = info["valid"]
        if self.post_questions:
            text, spec = P.post_questions()
            res = await self.gather([self.ask(p, "post", text, lambda o: validate_spec(o, spec), "Include every requested key.") for p in self.people])
            for p, (val, info) in zip(self.people, res):
                p.answers.update({f"post_{k}": v for k, v in (val or {}).items()})
                p.flags["post_valid"] = info["valid"]
        self.save()

    def save(self):
        d = self.out
        d.mkdir(parents=True, exist_ok=True)
        with open(d / f"{self.sid}_participants.jsonl", "w") as f:
            for p in self.people:
                f.write(json.dumps({"session": self.sid, "treatment": self.treatment, "seed": self.seed,
                                    "pid": p.pid, "model": p.model, "adv": p.adv, "answers": p.answers, "flags": p.flags,
                                    "invalid": p.invalid, "reprompts": p.reprompts}, ensure_ascii=False) + "\n")
        with open(d / f"{self.sid}_rounds.jsonl", "w") as f:
            for row in self.round_rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
