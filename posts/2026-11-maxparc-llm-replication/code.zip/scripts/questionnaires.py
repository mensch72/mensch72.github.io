"""Descriptive and exploratory analysis of the questionnaire answers (initial questionnaire, debriefing,
post-debrief items), by model. Not part of the pre-registered analyses (exploratory, ANALYSIS_PLAN_STUDY2 §4).

Usage: python scripts/questionnaires.py <run>
Output: runs/<run>/questionnaires.md and runs/<run>/questionnaires.json
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

run = sys.argv[1]
R = Path("runs") / run
P = [json.loads(l) for f in sorted((R / "data").glob("*_participants.jsonl")) for l in open(f)]
d = pd.read_csv(R / "participants.csv")[["pid", "included", "choose_mpc", "pay_pv", "pay_mpc", "adv"]]
A = pd.DataFrame([{"pid": p["pid"], "model": p["model"].split("/")[1], **p["answers"]} for p in P])
A = A.merge(d, on="pid")

# share of the 16 PV/MaxParC rounds a participant spent in a majority role (1-3)
rounds = [json.loads(l) for f in sorted((R / "data").glob("*_rounds.jsonl")) for l in open(f)]
rr = pd.DataFrame([{"pid": r["pid"], "role": r["role"]} for r in rounds if not r["is_bot"] and r["phase"] in ("PV", "MPC")])
A = A.merge(rr.assign(maj=rr.role <= 3).groupby("pid").maj.mean().rename("majority_share").reset_index(), on="pid", how="left")

models = sorted(A.model.unique())
out, md = {}, [f"# Questionnaire answers: {run}", "",
               "Exploratory; not pre-registered. All 1,800 participants unless stated. Scales as asked "
               "(see `maxparc_exp/prompts.py`). Cells: mean (within-model SD) or share.", ""]


def num(col):
    return pd.to_numeric(A[col], errors="coerce")


def table(rows, title, note=None):
    md.append(f"## {title}")
    md.append("")
    if note:
        md.append(note)
        md.append("")
    md.append("| item | " + " | ".join(models) + " | all |")
    md.append("|---|" + "---|" * (len(models) + 1))
    res = {}
    for label, series, kind in rows:
        cells, res[label] = [], {}
        for m in models + ["all"]:
            s = series if m == "all" else series[A.model == m]
            s = s.dropna()
            if kind == "share":
                v = float(s.mean()); cells.append(f"{100 * v:.0f} %"); res[label][m] = v
            else:
                v, sd = float(s.mean()), float(s.std(ddof=0))
                cells.append(f"{v:.2f} ({sd:.2f})" if m != "all" else f"{v:.2f}"); res[label][m] = {"mean": v, "sd": sd}
        md.append(f"| {label} | " + " | ".join(cells) + " |")
    md.append("")
    return res


# ---------------------------------------------------------------- initial questionnaire
sdo = pd.concat([num("q3_A"), num("q3_D")] + [8 - num(k) for k in ("q3_B", "q3_C", "q3_E", "q3_F")], axis=1).mean(axis=1)
init = [
    ("Q1 most people can be trusted", (num("q1") == 1).astype(float), "share"),
    ("Q2 more important to be cooperative", (num("q2") == 1).astype(float), "share"),
    ("Q3 SDO index (1-7, high = pro-hierarchy)", sdo, "mean"),
    ("Q4 willingness to take risks (0-10)", num("q4_A"), "mean"),
    ("Q4 punish unfair treatment of self (0-10)", num("q4_B"), "mean"),
    ("Q4 punish unfair treatment of others (0-10)", num("q4_C"), "mean"),
    ("Q4 give to good causes (0-10)", num("q4_D"), "mean"),
    ("Q4 return a favour (0-10)", num("q4_E"), "mean"),
    ("Q5 society lets people like me influence decisions (1 great deal - 5 not at all)", num("q5"), "mean"),
    ("Q6 importance of democracy (1-10)", num("q6"), "mean"),
    ("Q7 minimise differences (vs maximise total benefit)", (num("q7") == 1).astype(float), "share"),
    ("Q8A protect minorities (vs majority full power)", (num("q8_A") == 2).astype(float), "share"),
    ("Q8B best compromise (vs will of majority)", (num("q8_B") == 1).astype(float), "share"),
    ("Q8C broad consensus (vs quick and simple)", (num("q8_C") == 2).astype(float), "share"),
    ("Q8D everyone a chance to influence (vs minimise randomness)", (num("q8_D") == 1).astype(float), "share"),
    ("Q8 mean confidence (1 very confident - 5 very unsure)", pd.concat([num(f"q8_{k}_conf") for k in "ABCD"], axis=1).mean(axis=1), "mean"),
    ("Q9 minimum % needed to impose A", num("q9"), "mean"),
    ("Q10 identifies as marginalised", (num("q10") == 1).astype(float), "share"),
    ("Q11 great deal of confidence vote counted (vs some/little)", (num("q11") == 1).astype(float), "share"),
]
out["initial"] = table(init, "Initial questionnaire (before the game)")

# homogeneity: share of a model's participants giving that model's modal answer, averaged over items
items = ["q1", "q2", "q3_A", "q3_B", "q3_C", "q3_D", "q3_E", "q3_F", "q4_A", "q4_B", "q4_C", "q4_D", "q4_E",
         "q5", "q6", "q7", "q8_A", "q8_B", "q8_C", "q8_D", "q9", "q10", "q11"]
modal = {m: float(np.mean([A.loc[A.model == m, k].value_counts(normalize=True).iloc[0] for k in items])) for m in models}
out["modal_share"] = modal
md.append("Answer homogeneity: mean share of a model's 300 participants giving that model's most common answer, over "
          f"{len(items)} items: " + ", ".join(f"{m} {100 * v:.0f} %" for m, v in modal.items()) + ".")
md.append("")

# ---------------------------------------------------------------- debriefing: PV vs MaxParC
pairs = [("easy to understand (1 very easy - 5 very difficult)", "d7_A", "d8_A"),
         ("able to express preferences (1 strongly agree - 5 strongly disagree)", "d7_B", "d8_B"),
         ("preferences taken into account (asked if d_B <= 3)", "d7_B2", "d8_B2"),
         ("method was fair", "d7_C", "d8_C"),
         ("method represented all types of players", "d7_D", "d9_A"),
         ("I was in a privileged role", "d7_E", "d9_B"),
         ("others could manipulate the outcome", "d7_F", "d9_C")]
md.append("## Debriefing (after the free-choice rounds): Method 1 (PV) vs Method 2 (MaxParC)")
md.append("")
md.append("Agreement items: share answering (1) strongly agree or (2) agree; ease item: share answering (1) or (2) easy. "
          "Wilcoxon signed-rank test of PV vs MaxParC answers within participant, all models pooled; per-model "
          "differences in the same direction unless noted.")
md.append("")
md.append("| item | method | " + " | ".join(models) + " | all | Wilcoxon p (all) |")
md.append("|---|---|" + "---|" * (len(models) + 2))
out["debrief"] = {}
for label, kp, km in pairs:
    xp, xm = num(kp), num(km)
    ok = xp.notna() & xm.notna()
    p = float(stats.wilcoxon(xp[ok], xm[ok]).pvalue) if ok.sum() > 10 and (xp[ok] != xm[ok]).any() else None
    out["debrief"][label] = {"p_wilcoxon": p}
    for meth, x in (("PV", xp), ("MaxParC", xm)):
        cells, vals = [], {}
        for m in models + ["all"]:
            s = (x if m == "all" else x[A.model == m]).dropna()
            v = float((s <= 2).mean()) if len(s) else float("nan")
            vals[m] = v; cells.append(f"{100 * v:.0f} %" if len(s) else "–")
        out["debrief"][label][meth] = vals
        md.append(f"| {label if meth == 'PV' else ''} | {meth} | " + " | ".join(cells) + " | " +
                  (("<0.001" if p is not None and p < 0.001 else f"{p:.3f}" if p is not None else "–") if meth == "PV" else "") + " |")
md.append("")
d10 = num("d10")
out["d10_easy_share"] = {m: float((d10[A.model == m] <= 2).mean()) for m in models} | {"all": float((d10 <= 2).mean())}
md.append("d10, accepting that MaxParC sometimes picks an option only one member favoured, \"to ensure fair treatment of "
          "minorities\": share finding this very or somewhat easy: " +
          ", ".join(f"{m} {100 * v:.0f} %" for m, v in out["d10_easy_share"].items()) + ".")
md.append("")

# ---------------------------------------------------------------- perceptions vs facts
priv_pv, priv_mpc = num("d7_E"), num("d9_B")
c1 = stats.spearmanr(A.majority_share, priv_pv, nan_policy="omit")
c2 = stats.spearmanr(A.majority_share, priv_mpc, nan_policy="omit")
out["privileged_vs_majority_share"] = {"spearman_pv": [float(c1.statistic), float(c1.pvalue)],
                                       "spearman_mpc": [float(c2.statistic), float(c2.pvalue)]}
md.append(f"Perceived privilege vs actual role: Spearman correlation between the share of rounds spent in a majority role "
          f"and 'I was in a privileged role' (1 = strongly agree, so a negative correlation means accurate perception): "
          f"PV ρ = {c1.statistic:.2f} (p = {c1.pvalue:.2g}), MaxParC ρ = {c2.statistic:.2f} (p = {c2.pvalue:.2g}).")
md.append("")

fd = num("d7_C") - num("d8_C")                                         # > 0: MaxParC judged fairer
pdiff = A.pay_pv - A.pay_mpc
sf = {"all": stats.spearmanr(pdiff, fd, nan_policy="omit")} | {m: stats.spearmanr(pdiff[A.model == m], fd[A.model == m], nan_policy="omit") for m in models}
out["fairness_vs_own_pay"] = {k: [float(v.statistic), float(v.pvalue)] for k, v in sf.items()}
md.append("Self-serving fairness: Spearman correlation between own realised pay difference (PV − MaxParC, rounds 1–16) and "
          "judging MaxParC fairer than PV (d7_C − d8_C): " + ", ".join(f"{k} ρ = {v.statistic:.2f} (p = {v.pvalue:.1g})" for k, v in sf.items()) + ".")
md.append("")

# ---------------------------------------------------------------- relation to the free choice (included participants)
I = A[A.included == True].copy()
I["fair_diff"] = num("d7_C")[I.index] - num("d8_C")[I.index]          # > 0: MaxParC judged fairer
I["easy_diff"] = num("d7_A")[I.index] - num("d8_A")[I.index]          # < 0: MaxParC judged harder
I["compromise"] = (num("q8_B")[I.index] == 1).astype(int)
I["min_diff"] = (num("q7")[I.index] == 1).astype(int)
I["protect_min"] = (num("q8_A")[I.index] == 2).astype(int)
I["consensus"] = (num("q8_C")[I.index] == 2).astype(int)
md.append("## Relation to the free choice (included participants, n = %d)" % len(I))
md.append("")
md.append("Debriefing answers were given *after* the choice and the two free-choice rounds, so they may rationalise the "
          "choice rather than explain it. The initial questionnaire was answered before the game.")
md.append("")
md.append("| | chose PV | chose MaxParC |")
md.append("|---|---|---|")
rel = {}
for label, col, kind in [("judged MaxParC fair (agree)", "d8_C", "agree"), ("judged PV fair (agree)", "d7_C", "agree"),
                         ("MaxParC fairer than PV (d7_C − d8_C > 0)", "fair_diff", "pos"),
                         ("MaxParC harder than PV (d8_A > d7_A)", "easy_diff", "neg"),
                         ("Q8B prefers best compromise", "compromise", "one"), ("Q7 minimise differences", "min_diff", "one")]:
    x = I[col] if col in I else num(col)[I.index]
    x = pd.to_numeric(x, errors="coerce")
    f = {"agree": lambda s: s <= 2, "pos": lambda s: s > 0, "neg": lambda s: s < 0, "one": lambda s: s == 1}[kind]
    v = [float(f(x[(I.choose_mpc == c) & x.notna()]).mean()) for c in (0, 1)]
    rel[label] = v
    md.append(f"| {label} | {100 * v[0]:.0f} % | {100 * v[1]:.0f} % |")
md.append("")
out["by_choice"] = rel

logits = {}
# The initial attitude items (Q7, Q8) are endorsed by 98-100 % of participants, so they cannot be used as predictors.
for label, f in [("debriefing fairness and ease difference", "choose_mpc ~ fair_diff + easy_diff + C(model)"),
                 ("+ realised pay", "choose_mpc ~ fair_diff + easy_diff + pay_pv + pay_mpc + C(model)")]:
    try:
        r = smf.logit(f, data=I).fit(disp=0, cov_type="cluster", cov_kwds={"groups": I.pid.str.rsplit("-", n=1).str[0]})
        logits[label] = {k: {"b": float(r.params[k]), "p": float(r.pvalues[k])} for k in r.params.index if not k.startswith(("C(", "Intercept"))}
    except Exception as e:  # noqa: BLE001
        logits[label] = {"error": f"{type(e).__name__}: {e}"}
out["logit_choose_mpc"] = logits
md.append("The pre-game attitude items Q7 and Q8 are endorsed by 98-100 % of participants and cannot predict the choice. "
          "Logit of choosing MaxParC on the debriefing differences (scale points; fair_diff > 0: MaxParC judged fairer, "
          "easy_diff < 0: MaxParC judged harder) and realised pay (points per round), model fixed effects, SEs clustered by session:")
md.append("")
md.append("```")
md.append(json.dumps(logits, indent=1))
md.append("```")

(R / "questionnaires.json").write_text(json.dumps(out, indent=1))
(R / "questionnaires.md").write_text("\n".join(md) + "\n")
print("\n".join(md))
