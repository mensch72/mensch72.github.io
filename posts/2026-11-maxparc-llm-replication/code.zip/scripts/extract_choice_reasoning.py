"""Extract the reasoning behind the free method choice for the qualitative coding (Study 2 plan, Section 4).

Draws a seeded random sample of 20 included participants per model and writes, for each, the
reasoning (thinking blocks) and the visible reply of the final valid "choice" call, plus the
participant's realised pay difference (PV minus MaxParC) and choice.

Usage: python scripts/extract_choice_reasoning.py <run> [per_model] [max_chars]
Output: runs/<run>/choice_reasoning_sample.jsonl
"""
import json
import random
import sys
from pathlib import Path

import pandas as pd

run = sys.argv[1]
per_model = int(sys.argv[2]) if len(sys.argv) > 2 else 20
max_chars = int(sys.argv[3]) if len(sys.argv) > 3 else 6000
R = Path("runs") / run

d = pd.read_csv(R / "participants.csv")
d = d[d.included == True]

calls = {}
for f in sorted((R / "api_log").glob("*.jsonl")):
    for line in open(f):
        r = json.loads(line)
        if r.get("step") == "choice" and "response" in r:
            calls.setdefault(r["pid"], []).append(r)

rng = random.Random(f"{run}-qualitative-sample")
out = []
for model in sorted(d.model.unique()):
    pids = sorted(d[d.model == model].pid)
    for pid in sorted(rng.sample(pids, min(per_model, len(pids)))):
        rs = sorted(calls.get(pid, []), key=lambda r: r["attempt"])
        if not rs:
            continue
        r = rs[-1]
        thinking = "\n".join(b.get("thinking") or "" for b in r["response"]["content"] if b.get("type") == "thinking")
        text = "\n".join(b.get("text") or "" for b in r["response"]["content"] if b.get("type") == "text")
        row = d[d.pid == pid].iloc[0]
        out.append({"pid": pid, "model": model, "choice": int(row.choice), "pay_diff_pv_minus_mpc": float(row.pay_diff),
                    "thinking": thinking[-max_chars:], "reply": text[-max_chars:],
                    "thinking_truncated": len(thinking) > max_chars, "reply_truncated": len(text) > max_chars})

with open(R / "choice_reasoning_sample.jsonl", "w") as fh:
    for o in out:
        fh.write(json.dumps(o, ensure_ascii=False) + "\n")
print(f"{len(out)} participants written to {R / 'choice_reasoning_sample.jsonl'}")
