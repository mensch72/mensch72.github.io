# LLM replication: Plurality Voting vs MaxParC

This folder replicates the virtual lab experiment of Heitzig, Simmons & Constantino, "Fair group
decisions via non-deterministic proportional consensus", *Social Choice and Welfare* (2025),
main text Section 5 and Supplement Sections 2.4 and 3.4. The human participants are replaced by
independent conversations with `claude-haiku-5-5`.

The analysis plan is in [`ANALYSIS_PLAN.md`](ANALYSIS_PLAN.md) and was committed before any data were collected.

## Running

```bash
pip install -r requirements.txt
```

```bash
python run.py test                       # unit tests (MaxParC incl. Supplement 3.1.5.6, parsing)
```

```bash
python run.py pilot --budget 5           # 1 session x 10 participants per treatment
```

```bash
python run.py main --sessions 20 --n 20 --budget 80   # sessions per treatment, participants per session
```

```bash
python run.py analyze --run main         # re-run the analysis of a finished run
```

`--model` and `--effort` (with an explicit `--run` name) and `--seed-run` (reuse another run's
session seeds) exist only for exploratory comparisons. The defaults are the pre-registered settings,
and with the defaults the request bodies are byte-identical to before the flags were added.

Add `--fake` to `pilot` or `main` for an offline dry run against a random stand-in model. It makes no API calls and
writes to a separate run directory. It is for testing the pipeline only.

Re-running an interrupted command resumes it: every logged API response is replayed, with a
SHA-256 check that the request is identical, and only the missing calls are made. `--budget` is a
hard cap in USD on new API spending per invocation, computed from the `usage` of each response.

### API key

The code reads the key from `ANTHROPIC_API_KEY`, or from `MAXPARC_API_KEY` if the former is unset,
and never writes it to disk or to any log. In Claude Code cloud sessions, set `MAXPARC_API_KEY`
rather than `ANTHROPIC_API_KEY`, so that Claude Code itself does not pick up the key.

## Output (`runs/<run>/`)

- `api_log/<session>.jsonl`: one record per API call. Each record holds the request parameters,
  the messages appended since that participant's previous call, the message count, a SHA-256 of
  the full request body, the full response (all content blocks, including thinking summaries),
  `usage` and cost. The full request of any call can be reconstructed from the participant's
  earlier records. Failed calls are logged with their error.
- `data/<session>_participants.jsonl`: one record per participant, with all answers, flags
  (attention, comprehension, validity), invalid answers and re-prompts.
- `data/<session>_rounds.jsonl`: one record per participant and round. It holds the group,
  role, display order, payoffs, ballot (mapped to underlying options), raw answer, lottery,
  winner, points and approval sets.
- `participants.csv`, `analysis.json`, `analysis.md`, `run_summary.json`.

Underlying option keys: `MAJ` (majority option, A in Tables S1/S2), `MIN4`, `MIN5` (minority
options B, C), `PART` (partial compromise, D) and `FULL` (full compromise, E). Role 1 is the highest
advantage value in the group.

## Code

| file | content |
|---|---|
| `maxparc_exp/mechanisms.py` | MaxParC exactly as in Supplement 2.2.2.10 (exact rational arithmetic), plus Plurality with abstention |
| `maxparc_exp/design.py` | Tables S1/S2, payoff draws, the rational benchmark |
| `maxparc_exp/prompts.py` | all participant-facing text |
| `maxparc_exp/experiment.py` | session flow, rematching, answer parsing and validation, re-prompts |
| `maxparc_exp/llm.py` | API calls, logging, replay, budget cap |
| `maxparc_exp/analysis.py` | the pre-specified analysis |

## Design decisions and assumptions (not specified in the paper)

1. **Instructions.** The general instructions, the method descriptions, the comprehension
   questions, the attention item, the round screens, the feedback and the free-choice text were
   written for this study (`prompts.py`). The PV and MaxParC descriptions follow the paper's
   wording ("approve x if strictly less than r % of all voters do not approve x"). The
   questionnaire items are verbatim from Supplement 2.4.3. The methods are not named for the
   participants.
2. **Comprehension and attention.** Participants who fail keep playing, so that groups stay at
   five, but are excluded from the primary analysis. Comprehension feedback, including the
   correct answers, is shown to everyone.
3. **Free choice.** Groups for rounds 17–18 are formed only among participants who chose the
   same method, so each choice is decisive for the chooser's own group. A pool that is not a
   multiple of five is filled up with rational bots, as in the paper, and this is disclosed to the
   group. These are the only bots.
   - Under PV, a bot votes for its payoff favourite.
   - Under MaxParC, a bot rates its favourite 100, the full compromise 20 and everything else 0
     (the strategy profile of Proposition 2 for N = 5).
4. **PV abstention** is allowed. If nobody votes, all options tie and the winner is uniform.
5. **Roles.** Participants are told that they have fixed, hidden roles that affect which options
   favour whom. Nobody is told their advantage value or role. The other four persons' columns,
   and the order of the options, are shuffled every round, separately for each participant.
6. **Feedback after each round.** Participants see the vote counts (PV) or the approval scores
   and their own approvals (MaxParC), the winning probabilities, the chosen option, their own
   points and their running total. Individual ballots are not shown.
7. **Payoffs.** Every cell of Tables S1/S2 is drawn independently and uniformly from its integer
   interval every round, so option totals vary around 180. Payment framing as in the original:
   1 point = USD 0.01, though no one is paid.
8. **Demographics** (debriefing items 1–6) and debriefing item 11 (practice rounds) are not asked.
   The regressions have no demographic controls.
9. **No time limits.** The original allowed 45 s per decision.
10. **Model settings.** Default sampling, no system prompt, default effort. Adaptive thinking is
    Haiku 5.5's default. `display: "summarized"` is set only so that thinking summaries are
    returned and logged; it does not change behaviour. Automatic prompt caching is on; it affects
    cost only.
11. **Invalid answers.** One re-prompt naming the error, then a fallback, flagged and counted
    (see `ANALYSIS_PLAN.md`).
12. **Rational benchmark.** The paper's 44.8 % could not be reproduced exactly. The derivation in
    `design.rational_cutoff` gives 44.2 % (low) and 50.1 % (high). Both are reported.
