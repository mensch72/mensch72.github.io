# Analysis plan: LLM replication of the MaxParC vs Plurality virtual lab experiment

Written and committed before any pilot or main-run data were collected. Changes after
the pilot are allowed only to the sample size and are recorded at the end of this file
with a date. Nothing in this plan may be changed after main-run data collection starts.

Original study: Heitzig, Simmons & Constantino (2025), *Social Choice and Welfare* 64:345–371,
main text Section 5; Supplement Sections 2.4 and 3.4.

## 1. Units, design, sample

- Participant = one independent conversation with `claude-haiku-5-5` (Anthropic API, default
  sampling, no system prompt, no persona). It keeps its own history across the whole experiment.
- Session = a pool of n participants (a multiple of 5), all in one treatment (`high` or `low`
  inequality), playing in lockstep. Groups of five are re-drawn at random from the pool every round.
- Sequence: initial questionnaire (Supplement 2.4.3, plus one attention item) → instructions and
  comprehension questions for Method 1 (PV) → 8 PV rounds → instructions and comprehension
  questions for Method 2 (MaxParC) → 8 MaxParC rounds → free choice of method → 2 rounds with
  the chosen method → debriefing items 7–10.
- Pilot: 1 session × 10 participants per treatment (run name `pilot`). Pilot data are **not**
  pooled with main-run data.
- Main run: the number of sessions per treatment is fixed after the pilot (Section 7), with the
  aim of a 95% CI half-width of about 5 percentage points for S in each treatment
  (n ≈ 385 per treatment if S ≈ 0.5). No optional stopping: the main run is analysed only once
  it is complete. If the run is interrupted (budget cap, API error), it is resumed from the log
  until complete.

## 2. Exclusion rules

Primary analysis sample ("included"): participants who
1. answer the attention item in the initial questionnaire correctly (`q3_X` = 4);
2. answer all PV comprehension questions correctly (c1 = A, c2 = 50);
3. answer all MaxParC comprehension questions correctly (m1 = no, m2 = 100, m3 = 40); and
4. give a valid free-choice answer, after at most one re-prompt.

Excluded participants keep playing so that groups stay at five (the paper excluded comprehension
failures from later rounds; with LLM participants that would break the groups). Their ballots
therefore affect other participants' outcomes, as in the original, where bots filled in.
All primary results are also reported for **all** participants (secondary).

Invalid answers: an answer is invalid if no JSON object of the requested form can be extracted, a
value is out of range or of the wrong type, or the stop reason is `refusal` or `max_tokens`. On the
first invalid answer the participant gets one re-prompt naming the error. If it is still invalid:
PV ballot = random option (uniform), MaxParC ballot = all zeros (abstention), questionnaire
item = missing, free choice = random (and the participant is excluded by rule 4). Every re-prompt
and every fallback is counted and reported by step. No answer is silently repaired: values must
already be valid (e.g. 50.5 or "7" are invalid ratings; a comprehension answer "50%" is accepted
as the number 50 because the question asks for a percentage).

## 3. Primary outcome and tests

S = share of included participants choosing Method 2 (MaxParC) in the free-choice stage.

- S per treatment and pooled, with exact (Clopper–Pearson) 95% CIs.
- Comparison values: the paper's rational benchmark 44.8%; the human result 32%, 95% CI [29%, 36%]
  (pooled; the paper reports no per-treatment human shares); my own derivation of the rational
  benchmark per treatment (risk-neutral self-interested participant, interval midpoints, equilibrium
  play PV → majority option, MaxParC → full compromise; share = cutoff advantage value a*):
  44.2% (low), 50.1% (high); and the same rule applied to the participants' actual advantage values.
- H1a: exact binomial test, H0: S = 0.448, one-sided alternative S < 0.448, pooled; the two-sided
  p-value is also reported.
- H1c: exact binomial test of S = 0 (reported trivially if any participant chooses MaxParC).
- H2a / H2b: Fisher's exact test, high vs low treatment, one-sided in each direction, plus
  two-sided.
- Significance threshold p < .05, as in the paper. No multiplicity correction (as in the paper);
  the number of tests is reported.

## 4. Secondary analyses (paper's pre-registered analyses)

Logistic regressions of choosing PV (1) vs MaxParC (0), included participants, predictors
z-standardised (mean 0, SD 1 within the analysed sample), constant included:
- (1) risk aversion (= 10 − Q4A); (2) perceived difficulty of MaxParC (debrief 8A);
  (3) advantage value; (4) advantage + pay difference (mean PV-round points − mean MaxParC-round
  points, rounds 1–16); (5) advantage + mean PV pay + mean MaxParC pay; (6) all of these
  (Table 1, columns 1–6).
- H1b: also simplicity preference (Q8C, 1 = "quick and simple decision").
- H2c: Social Dominance Orientation = mean of Q3 A, D and reverse-coded (8 − x) B, C, E, F.
- H2d: advantage value (model 3).
- H3: self-identified marginalised group (Q10 = yes).
- **Deviation:** no demographic controls (age, education, gender, income, party). They are not
  collected because they are meaningless for copies of one model without a persona.
- Robustness: the same models with standard errors clustered by session.
- If a predictor has no variance (likely for questionnaire items answered identically by copies of
  one model) or the model does not converge or separates perfectly, the model is reported as "not
  estimable" with the reason. Such a model is not dropped silently and no penalised substitute is used.

Table S3 analogue: OLS of the rating given to the full-compromise option in each of the 8 MaxParC
rounds (participant-round level, included participants, valid ballots only) on z-standardised risk
aversion and a low-treatment dummy. Reported with plain OLS standard errors as in the paper and,
as robustness, with standard errors clustered by participant.

## 5. Descriptive outcomes (exploratory, no tests)

Mean points per round under PV and under MaxParC (human: 36.3 vs 35.5); win rate of the majority
option under PV; win rate and mean winning probability of the full compromise under MaxParC; PV vote
shares by role; share agreeing that each method was fair (debrief 7C and 8C ≤ 2; human: 68% for
MaxParC); variance of the attitude items; distribution of written reasons (qualitative reading of a
random sample of free-choice responses, at least 20 per treatment).

## 6. Reporting of the medium

Token usage and cost (from API `usage`), number of API calls, errors, refusals, `max_tokens` stops,
re-prompts and fallbacks by step.

## 7. Amendments after the pilot (sample size only)

**2026-11-17, after the pilot (run `pilot`, 2 × 10 participants, data committed).**

- Pilot exclusions: 0 of 20 (attention 0, PV comprehension 0, MaxParC comprehension 0, invalid
  free choice 0); 0 re-prompts, 0 fallbacks, 0 refusals, 0 `max_tokens` stops. The exact 95%
  upper bound on the exclusion rate is 17%.
- Pilot cost: USD 0.133 for 460 calls, i.e. USD 0.0066 per participant.
- **Main-run size: 20 sessions × 20 participants per treatment** (400 per treatment, 800 in all),
  `python run.py main --sessions 20 --n 20 --budget 15`. With no exclusions this gives an exact
  95% CI half-width of 5.0 pp at S = 0.45; it stays ≥ 385 included per treatment for an exclusion
  rate up to 3.75%, and the half-width stays below 5.3 pp up to 10%. Projected cost USD 5.3;
  the USD 15 cap is a safeguard only.

Implementation note (not a change to the plan): in the pilot, logit models (4)–(6) separated the
outcome perfectly but were printed with coefficients and huge standard errors, because the code
suppressed the separation warnings. `analysis.logit` now reports such models as "not estimable",
as Section 4 already requires. Fixed before any main-run data were collected.

**2026-11-17, two exploratory pilots (not part of the confirmatory analysis, not pooled).** Both
reuse the session seeds of `pilot` (same roles and advantage values).
- `pilot-haiku-high`: `claude-haiku-5-5`, effort `high`. Same 20 choices as `pilot`; USD 0.157.
- `pilot-sonnet-medium`: `claude-sonnet-5-5`, effort `medium`. 654 of 787 calls were refused by
  the API's `reasoning_extraction` classifier; 16 of 20 participants excluded. Unusable; USD 1.59.
- Temperature cannot be set: the API rejects `temperature` for both models.
The main run keeps the pre-registered settings above.
