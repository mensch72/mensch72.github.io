#!/usr/bin/env python3
"""One-command entry point.

  python run.py test                          # unit tests (MaxParC etc.)
  python run.py pilot  [--budget 5]           # 1 session x 10 participants per treatment
  python run.py main --sessions 20 --n 20 [--budget 60]
  python run.py analyze --run pilot           # analysis of a finished run
  add --fake to pilot/main for an offline dry run (no API calls, separate run dir)

Re-running the same pilot/main command resumes an interrupted run: logged API
responses are replayed, only missing calls are made.
"""
import argparse, asyncio, hashlib, json, subprocess, sys, time
from pathlib import Path

from maxparc_exp.experiment import Session
from maxparc_exp.llm import LLM, BudgetExceeded

ROOT = Path(__file__).resolve().parent


def seed_for(run, treatment, i):
    return int(hashlib.sha256(f"{run}|{treatment}|{i}".encode()).hexdigest(), 16) % 2**31


async def run_sessions(run, sessions, n, budget, fake, concurrency, model=None, effort=None, seed_run=None,
                       pool=None, treatments=("high", "low"), post_questions=False, model_opts=None):
    rdir = ROOT / "runs" / run
    llm = LLM(rdir / "api_log", budget, concurrency=concurrency, fake=fake, effort=effort,
              backend="openrouter" if pool else "anthropic", **({"model": model} if model else {}))
    llm.model_opts = model_opts or {}
    specs = [(t, i) for i in range(sessions) for t in treatments]
    t0 = time.time()
    tasks = [Session(llm, f"{run}-{t}-s{i:02d}", t, n, seed_for(seed_run or run, t, i), rdir / "data", models=pool,
                     post_questions=post_questions).run() for t, i in specs]
    status = "complete"
    try:
        await asyncio.gather(*tasks)
    except BudgetExceeded as e:
        status = f"stopped: {e}"
    summary = {"run": run, "status": status, "sessions_per_treatment": sessions, "n_per_session": n,
               "fake": fake, "model": llm.model if not pool else "openrouter pool", "pool": pool, "treatments": list(treatments), "post_questions": post_questions, "model_opts": model_opts or {}, "effort": effort or "default", "seed_run": seed_run or run,
               "new_calls": llm.calls_new, "replayed_calls": llm.calls_replayed,
               "cost_new_usd": round(llm.spent_new, 4), "cost_replayed_usd": round(llm.spent_replayed, 4),
               "wall_s": round(time.time() - t0, 1)}
    (rdir / "run_summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary, indent=1))
    return status


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["test", "pilot", "main", "analyze"])
    ap.add_argument("--run")
    ap.add_argument("--sessions", type=int, default=1)
    ap.add_argument("--n", type=int, default=10)
    ap.add_argument("--budget", type=float, default=5.0)
    ap.add_argument("--concurrency", type=int, default=32)
    ap.add_argument("--fake", action="store_true")
    ap.add_argument("--model", help="default: claude-haiku-5-5 (the pre-registered model)")
    ap.add_argument("--effort", choices=["low", "medium", "high", "xhigh", "max"],
                    help="default: not sent (model default; pre-registered)")
    ap.add_argument("--pool", help="comma-separated OpenRouter model ids, or a file with one id per line; "
                    "participants are assigned round-robin; uses the OpenRouter backend")
    ap.add_argument("--treatments", default="high,low", help="comma-separated subset of high,low")
    ap.add_argument("--post-questions", action="store_true", help="ask the Study 2 post-debrief items (u1, r1, r2)")
    ap.add_argument("--seed-run", help="reuse the session seeds of this run (same roles and first payoff draws)")
    a = ap.parse_args()
    if a.cmd == "test":
        sys.exit(subprocess.call([sys.executable, "-m", "pytest", "-q", str(ROOT / "tests")]))
    if a.cmd == "analyze":
        from maxparc_exp.analysis import analyze
        analyze(ROOT / "runs" / a.run)
        return
    if a.n % 5:
        sys.exit("--n must be a multiple of 5")
    run = a.run or (a.cmd + ("-fake" if a.fake else ""))
    if (a.model or a.effort or a.pool) and not a.run:
        sys.exit("--model/--effort/--pool need an explicit --run name")
    pool, model_opts = None, {}
    if a.pool:
        # one model per line (or comma-separated); optional "reasoning=on" and/or
        # "ignore=ProviderA+ProviderB" (OpenRouter providers not to route to) after the id
        entries = [l.split("#")[0].strip() for l in (Path(a.pool).read_text().splitlines() if Path(a.pool).is_file() else a.pool.split(","))]
        pool = []
        for e in filter(None, entries):
            mid, *opts = e.split()
            pool.append(mid)
            for o in opts:
                if o == "reasoning=on":
                    model_opts.setdefault(mid, {})["reasoning"] = {"enabled": True}
                elif o.startswith("ignore="):
                    model_opts.setdefault(mid, {})["provider"] = {"ignore": o[len("ignore="):].split("+")}
                else:
                    sys.exit(f"unknown model option {o!r}")
    treatments = tuple(t for t in a.treatments.split(",") if t)
    assert set(treatments) <= {"high", "low"}, a.treatments
    if a.cmd == "pilot" and not pool:
        a.sessions, a.n = 1, 10
    status = asyncio.run(run_sessions(run, a.sessions, a.n, a.budget, a.fake, a.concurrency,
                                      a.model, a.effort, a.seed_run, pool, treatments, a.post_questions,
                                      model_opts))
    if status == "complete":
        from maxparc_exp.analysis import analyze
        analyze(ROOT / "runs" / run)


if __name__ == "__main__":
    main()
