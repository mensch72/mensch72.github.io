# Analysis plan, Study 2: pool of open-weight models (low-inequality treatment)

Written and committed before any Study 2 main-run data were collected (2026-11-17). Study 1
(`ANALYSIS_PLAN.md`, `claude-haiku-5-5`) is not run as a main study; its pilot is reported as a pilot.
Nothing in this plan may be changed after main-run data collection starts.

## 1. Design

- Participant = one independent conversation with one model through OpenRouter (default sampling,
  no system prompt, no persona). Participant-facing text, session flow, payoffs, exclusion rules and
  invalid-answer handling are exactly as in Study 1 (`ANALYSIS_PLAN.md` Sections 1–2), except:
  - **Treatment:** low inequality only (Table S2). The high-inequality treatment is dropped: there the
    full compromise is worse than the random-ballot benchmark lottery for voters 4 and 5
    (24 and 12 vs 36 points), so the full-compromise equilibrium does not exist there.
  - **Post-debrief items** (after all decisions; cannot affect them): u1 (understanding of a safe
    conditional commitment; correct answer 2), r1 and r2 (sure 36 points vs the benchmark lottery of
    a majority member, 58 w.p. 60 % else 3, and of a minority member, 168 w.p. 20 % else 3; both EV 36).
- **Pool** (`pools/main6.txt`): deepseek/deepseek-v4.1-flash, qwen/qwen3.8-flash,
  google/gemma-4-31b-it, openai/gpt-oss-120b, nvidia/nemotron-3.5-super-vl, meta/muse-glimmer-30b.
  One model per family. Excluded after pilots: z-ai/glm-5.3 (`pilot-or8`: output-limit failures in
  7 of 10 MaxParC decisions) and mistralai/mistral-small-2603 (`pilot-or7r`: with reasoning on,
  4 of 5 failed the MaxParC comprehension check, vs 0 of 10 with reasoning off in `pilot-or7`;
  excluded by decision of the PI rather than run with reasoning off, so that every model's
  reasoning is logged).
  Gemma runs with OpenRouter reasoning enabled (it does not reason by default); all others run with
  their default reasoning behaviour. Provider routing is OpenRouter's default, except that
  gpt-oss is not routed to PrimeIntellect, which returned no reasoning (0 reasoning tokens in 113 of
  113 calls in `pilot-or7r`; 4 of 5 of those participants failed the MaxParC comprehension check).
  The serving provider of every call is logged.
- **Sessions:** mixed pools of 30 participants, 5 per model, groups of five re-drawn at random
  every round from the whole session. Bots only fill free-choice groups (as in Study 1).
- **Sample:** 60 sessions × 30 = 1,800 participants, 300 per model. Fixed in advance, no optional
  stopping; an interrupted run is resumed from the log until complete. Run name `main-or6`,
  budget cap USD 90 (expected ≈ USD 61 from the pilots' cost per participant).
- **Archiving:** every API call is logged with request, full response text, reasoning text and
  structured reasoning details, usage, billed cost and provider (`runs/main-or6/api_log`).
  Partial results are committed and pushed during the run.

## 2. Primary outcome

S_m = share of included participants of model m choosing Method 2 (MaxParC), with exact
Clopper–Pearson 95 % CIs, for each of the 6 models.

Pooled S = share among all included participants (equal n per model by design), reported with
(a) the exact binomial CI, which is conditional on this pool, and (b) a t-interval across the 6
per-model shares (df = 5), which treats models as a sample of models. The pooled value depends on
the choice of pool and is secondary to the per-model shares.

Comparison values: human 32 % [29, 36] (pooled over both of the paper's treatments; no
low-treatment value is reported); the paper's rational benchmark 44.8 %; for the low treatment,
44.2 % (cutoff with MaxParC → full compromise) and 44.4 % (cutoff with MaxParC → random-ballot
lottery); and the 44.2 % rule applied to the participants' actual advantage values.

Tests (p < .05, no multiplicity correction, number of tests reported):
- H1a: exact binomial test of S = 0.448 vs S < 0.448, per model and pooled; two-sided p also reported.
- Heterogeneity: chi-square test of equal S across the 6 models (Monte-Carlo p-value if expected
  counts < 5).
- H2a/H2b (treatment differences) are not applicable.

## 3. Secondary analyses

- Logit of choosing PV on z-standardised predictors as in Study 1 Section 4 (models 1–6, H1b, H2c,
  H2d, H3), with model fixed effects and standard errors clustered by session; also per model.
  Not-estimable rules as in Study 1 (no variance, separation, non-convergence).
- H4 (new): understanding (u1 = 2) is associated with choosing MaxParC (logit, two-sided).
- H5 (new): preferring the sure 36 points in r1 (majority lottery) or r2 (minority lottery) is
  associated with choosing MaxParC (logit, two-sided).
- Table S3 analogue: OLS of the rating of the full compromise (MaxParC rounds, valid ballots) on
  z-standardised risk aversion with model fixed effects; plain and participant-clustered SEs.

## 4. Descriptive and exploratory

Per model: comprehension and exclusions, re-prompts and fallbacks, PV votes by role, MaxParC ballots
(share rating the full compromise above 0, mean rating, single-option ballots), points per round,
u1/r1/r2 distributions, cost and tokens. Per session/group: win rate and mean winning probability
of the full compromise. Whether a participant's choice follows the sign of its own realised pay
difference (PV minus MaxParC). Qualitative coding of the reasoning behind the free choice in a
random sample of 20 participants per model, categories: own realised payoff, expected payoff /
strategy, fairness or equality, risk, complexity, other.

## 5. Limitations to report

Participants are unpaid; copies of a model are not independent; the models may know the paper or
the mechanism; pool composition determines pooled S; attitude items vary little within a model;
providers behind OpenRouter may differ in quantisation; the human comparison value pools both
treatments.
