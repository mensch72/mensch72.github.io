from maxparc_exp.experiment import last_json_object, v_ratings, v_vote, validate_spec


def test_outermost_object_is_used():
    t = 'I think D. {"x": 1} Final: {"ratings": {"A": 83, "B": 32, "C": 54, "D": 23, "E": 34}}'
    assert v_ratings(last_json_object(t))[0]["ratings"]["A"] == 83


def test_last_object_wins_and_null_vote():
    assert v_vote(last_json_object('{"vote": "A"} hmm, actually {"vote": null}'))[0] == {"vote": None}


def test_no_silent_repair():
    assert v_ratings({"ratings": {"A": 50.5, "B": 0, "C": 0, "D": 0, "E": 0}})[0] is None
    assert v_ratings({"ratings": {"A": 101, "B": 0, "C": 0, "D": 0, "E": 0}})[0] is None
    assert v_vote({"vote": "F"})[0] is None
    assert validate_spec({"q1": "1"}, {"q1": {1, 2}})[0] is None
