from fractions import Fraction as F
import itertools, random
from maxparc_exp.mechanisms import maxparc, plurality, approval_set

OPTS = ["x1", "x2", "x3", "x4", "z", "z'"]


def ballot(top, mid, mid_val=0.51, extra=None):
    b = {o: 0 for o in OPTS}
    b[top] = 1
    b[mid] = mid_val
    if extra:
        b.update(extra)
    return b


def canonical():
    # Supplement 3.1.5.6: N=6, factions F1(1) F2(2) F3(2) F4(1)
    return [ballot("x1", "z"), ballot("x2", "z"), ballot("x2", "z"),
            ballot("x3", "z'"), ballot("x3", "z'"), ballot("x4", "z'")]


def test_supplement_3156_canonical():
    p = maxparc(canonical(), OPTS)
    assert p["z"] == F(1, 2) and p["z'"] == F(1, 2)
    assert sum(p.values()) == 1


def test_supplement_3156_middle_factions_deviation():
    b = canonical()
    for i in (1, 2):  # F2 additionally rates x3 at 35
        b[i]["x3"] = 0.35
    for i in (3, 4):  # F3 additionally rates x2 at 35
        b[i]["x2"] = 0.35
    p = maxparc(b, OPTS)
    assert p["x2"] == F(1, 3) and p["x3"] == F(1, 3)
    assert p["z"] == F(1, 6) and p["z'"] == F(1, 6)


def test_supplement_3156_betrayal():
    # F2 defects from the deviation (does not rate x3), F3 keeps rating x2 at 35
    b = canonical()
    for i in (3, 4):
        b[i]["x2"] = 0.35
    p = maxparc(b, OPTS)
    assert p["x2"] == F(2, 3)  # F2's and F3's votes all go to x2
    assert p["z"] == F(1, 6) and p["z'"] == F(1, 6)


def test_abstention_and_all_abstain():
    o = ["a", "b"]
    p = maxparc([{"a": 1, "b": 0}, {"a": 0, "b": 0}], o)  # voter 2 abstains
    assert p == {"a": 1, "b": 0}
    p = maxparc([{"a": 0, "b": 0}, {"a": 0, "b": 0}], o)  # everyone abstains -> tie
    assert p == {"a": F(1, 2), "b": F(1, 2)}


def test_proportionality_bullet_votes():
    o = ["a", "b"]
    p = maxparc([{"a": 1, "b": 0}] * 2 + [{"a": 0, "b": 1}] * 3, o)
    assert p == {"a": F(2, 5), "b": F(3, 5)}


def test_full_consensus_equilibrium_five():
    # Prop. 2 profile in a group of five: favourite at 100, E at 20 -> E for sure
    o = list("ABCDE")
    fav = ["A", "A", "A", "B", "C"]
    b = [{x: (1 if x == f else (0.2 if x == "E" else 0)) for x in o} for f in fav]
    assert maxparc(b, o)["E"] == 1
    # one defector withdraws from E: approval collapses (4/5 + 0.2 = 1, not > 1)
    b[3]["E"] = 0
    p = maxparc(b, o)
    assert p["E"] == 0 and p["A"] == F(3, 5)


def test_approval_set_brute_force():
    rng = random.Random(1)
    for _ in range(2000):
        n = rng.randint(1, 6)
        r = [F(rng.choice([0, 10, 20, 21, 35, 40, 41, 51, 60, 80, 81, 100]), 100) for _ in range(n)]
        best = set()
        for k in range(n + 1):
            for A in itertools.combinations(range(n), k):
                if all(F(len(A), n) + r[i] > 1 for i in A) and len(A) > len(best):
                    best = set(A)
        assert set(approval_set(r)) == best


def test_plurality():
    o = list("ABC")
    assert plurality(["A", "A", "B"], o)["A"] == 1
    assert plurality(["A", "B", None], o) == {"A": F(1, 2), "B": F(1, 2), "C": 0}
    assert plurality([None, None], o) == {x: F(1, 3) for x in o}
