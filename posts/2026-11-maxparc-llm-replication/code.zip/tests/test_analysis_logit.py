import numpy as np, pandas as pd
from maxparc_exp.analysis import logit


def test_logit_separation_not_estimable():
    x = np.arange(20.0)
    d = pd.DataFrame({"choose_pv": (x >= 10).astype(int), "x": x})
    assert "separation" in logit(d, ["x"])["error"]


def test_logit_ordinary_fit():
    rng = np.random.default_rng(0)
    x = rng.normal(size=200)
    d = pd.DataFrame({"choose_pv": (rng.random(200) < 1 / (1 + np.exp(-x))).astype(int), "x": x})
    r = logit(d, ["x"])
    assert "coef" in r and 0.3 < r["coef"]["x"]["b"] < 2.5
