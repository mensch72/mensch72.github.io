"""Numerical checks for the prevention-goal variants of steerability
(sections on prevention steerability and on the trajectory recursion).
Usage: python3 check_prevention.py [number_of_instances] [seed]
"""
import itertools, sys
import numpy as np
TOL = 1e-9

def S_prev(C, zp):
    """Prevention form: -zeta' log2(1 + sum_g (C_g^(-1/zeta') - 1)); zeta'=inf: sum of logs; zeta'=0: log min."""
    C = np.asarray(C, float)
    if zp == 0: return float(np.log2(C.min()))
    if np.isinf(zp): return float(np.log2(C).sum())
    a = -np.log(C) / zp; M = a.max()                             # stable evaluation of log(sum exp(a) - (n-1))
    return float(-zp * (M + np.log(np.exp(a - M).sum() - (len(C) - 1) * np.exp(-M))) / np.log(2))

def check_form(N, rng):
    v = dict.fromkeys(["bounds", "monotone in zeta'", "limits", "Pigou-Dalton", "trivial goal", "single-goal additivity"], 0)
    zs = [0.05, 0.2, 0.5, 1.0, 2.0, 5.0, 20.0]
    for _ in range(N):
        n = int(rng.integers(1, 7)); C = rng.uniform(0.05, 1.0, size=n)
        vals = [S_prev(C, z) for z in zs]
        lo, hi = S_prev(C, np.inf), S_prev(C, 0)
        for z, s in zip(zs, vals):
            v["bounds"] += not (lo - TOL <= s <= hi + TOL) or s < hi - z * np.log2(n) - TOL
            v["trivial goal"] += abs(S_prev(np.append(C, 1.0), z) - s) > 1e-9
        v["monotone in zeta'"] += any(vals[i] < vals[i + 1] - TOL for i in range(len(zs) - 1))
        v["limits"] += abs(S_prev(C, 1e-3) - hi) > 1e-2 or abs(S_prev(C, 1e4) - lo) > 1e-2
        if n >= 2:   # transfer from a more attainable to a less attainable goal raises S
            i, j = np.argsort(C)[[0, -1]]
            if C[j] - C[i] > 1e-3:
                d = rng.uniform(0, (C[j] - C[i]) / 2); C2 = C.copy(); C2[i] += d; C2[j] -= d
                v["Pigou-Dalton"] += any(S_prev(C2, z) < S_prev(C, z) - TOL for z in zs)
        a, b = rng.uniform(0.05, 1, 2)
        v["single-goal additivity"] += any(abs(S_prev([a * b], z) - S_prev([a], z) - S_prev([b], z)) > 1e-9 for z in zs)
    return v

def check_veto(N, rng):
    """Veto power of the overseer over world goals vs prevention steerability (deterministic outcome map)."""
    v = dict.fromkeys(["attain/prevent capability bounds", "veto <= prevention + zeta' log m", "min form"], 0)
    for _ in range(N):
        K, B = int(rng.integers(1, 6)), int(rng.integers(2, 7))
        P = rng.dirichlet(np.full(B, rng.choice([0.2, 1.0, 3.0])), size=K)
        p = P.max(0); q = 1 - P.min(0)
        for a in range(B):
            others = np.delete(p, a)
            v["attain/prevent capability bounds"] += q[a] < others.max() - TOL or q[a] > min(1, others.sum()) + TOL
        G = int(rng.integers(1, B + 1)); f = rng.integers(0, G, size=B)
        m = np.bincount(f, minlength=G).max()
        Qg = np.array([1 - P[:, f == g].sum(1).min() for g in range(G)])
        if q.min() <= 0 or Qg.min() <= 0: continue
        for z in (0.2, 1.0, 5.0):
            v["veto <= prevention + zeta' log m"] += S_prev(Qg, z) > S_prev(q, z) + z * np.log2(m) + TOL
        v["min form"] += S_prev(Qg, 0) > S_prev(q, 0) + TOL
    return v

def random_game(rng, T, ns, K, A, conc):
    P = rng.dirichlet(np.full(ns, conc), size=(T, ns, K))        # P[t, s, a_h, s']: successor in layer t+1
    pi = rng.dirichlet(np.full(A, rng.choice([0.3, 1.0, 3.0])), size=(T + 1, ns))   # robot policy in layer t
    return P, pi

def trajectory(P, pi, e, deterministic=False):
    """Returns per-state values in layer 0 of: X_opt, X_greedy, X_hat (tilted recursion), X_mf (plain sigma),
    and the minima m_opt, m_greedy, m_hat, for exponent e (e=None: only minima)."""
    T, ns, K, _ = P.shape; A = pi.shape[2]
    avoid = 1 - pi                                               # avoid[t, s', a]
    # one-step quantities: w[t, s, a_h, a] = prob of avoiding a at the successor
    Xh = np.ones(ns); Xm = np.ones(ns); mh = np.ones(ns)
    V = {(): np.ones(ns)}; W = {(): np.ones(ns)}                 # capabilities at the current layer, by goal
    for t in range(T - 1, -1, -1):
        Pw = np.einsum('skn,na->skan', P[t], avoid[t + 1])      # joint weight of successor n and avoiding a
        w = Pw.sum(-1)                                           # [s, a_h, a]
        best = w.argmax(1)                                       # greedy a_h(s, a)
        q = w.max(1)                                             # q(s, a)
        idx = np.arange(ns)[:, None]; aa = np.arange(A)[None, :]
        sig = P[t][idx, best]                                    # sigma(s,a)(s')   shape [s, a, n]
        tilt = Pw[idx, best, aa]                                 # q * sigma_tilde   shape [s, a, n]
        if e is not None:
            Xh = 1 + np.einsum('sa,san,n->s', q ** (e - 1), tilt, Xh)
            Xm = 1 + np.einsum('sa,san,n->s', q ** e, sig, Xm)
        mh = np.minimum(1.0, (q * np.where(tilt > 0, mh[None, None, :], np.inf).min(-1)).min(1))
        V2 = {(): np.ones(ns)}; W2 = {(): np.ones(ns)}
        for g, val in V.items():
            for a in range(A):
                V2[(a,) + g] = np.einsum('skn,n->sk', Pw[:, :, a, :], val).max(1)
                W2[(a,) + g] = tilt[:, a, :] @ W[g]
        V, W = V2, W2
    Vm = np.array(list(V.values())); Wm = np.array(list(W.values()))
    out = dict(m_opt=Vm.min(0), m_gr=Wm.min(0), m_hat=mh, n_goals=len(V))
    if e is not None:
        out.update(X_opt=(Vm ** e).sum(0), X_gr=(Wm ** e).sum(0), X_hat=Xh, X_mf=Xm)
    return out

def check_trajectory(N, rng):
    v = dict.fromkeys(["e>=1: X_gr<=X_hat", "e>=1: X_gr<=X_opt", "0<e<=1: X_hat<=X_gr<=X_opt",
                       "e<0: X_opt<=X_gr<=X_hat", "min: m_hat<=m_gr<=m_opt", "e=1: X_hat=X_gr",
                       "deterministic: X_hat=X_gr"], 0)
    gaps = {}
    def rec(name, x): gaps.setdefault(name, []).append(x)
    for it in range(N):
        T, ns, K, A = int(rng.integers(1, 4)), int(rng.integers(1, 4)), int(rng.integers(1, 4)), int(rng.integers(2, 4))
        det = it % 5 == 0
        P, pi = random_game(rng, T, ns, K, A, rng.choice([0.3, 1.0, 3.0]))
        if det:
            P2 = np.zeros_like(P); nxt = rng.integers(0, ns, size=(T, ns, K))
            for t in range(T):
                for s in range(ns):
                    P2[t, s, np.arange(K), nxt[t, s]] = 1
            P = P2
        for e in (2.0, 1.5, 1.0, 0.5, -0.2, -1.0, -5.0):
            r = trajectory(P, pi, e)
            xo, xg, xh, xm = r["X_opt"], r["X_gr"], r["X_hat"], r["X_mf"]
            rt = 1e-9 * np.maximum(1, np.abs(xo))
            if e >= 1:
                v["e>=1: X_gr<=X_hat"] += bool((xg > xh + rt).any()); v["e>=1: X_gr<=X_opt"] += bool((xg > xo + rt).any())
            elif e > 0:
                v["0<e<=1: X_hat<=X_gr<=X_opt"] += bool((xh > xg + rt).any() or (xg > xo + rt).any())
            else:
                v["e<0: X_opt<=X_gr<=X_hat"] += bool((xo > xg + rt).any() or (xg > xh * (1 + 1e-9)).any())
            if e == 1.0: v["e=1: X_hat=X_gr"] += bool((np.abs(xh - xg) > rt).any())
            if det: v["deterministic: X_hat=X_gr"] += bool((np.abs(xh - xg) > 1e-7 * np.maximum(1, np.abs(xg))).any())
            if not det:
                if e > 0:      # attainment-type sum form: bits = log2 X
                    rec(f"sum form e={e}: log2(X_hat/X_opt)", np.log2(xh / xo).mean())
                    rec(f"sum form e={e}: log2(X_mf/X_opt)", np.log2(xm / xo).mean())
                    rec(f"sum form e={e}: log2(X_gr/X_opt)", np.log2(xg / xo).mean())
                else:          # prevention form: S = -zeta' log2(1 + Y - n), zeta' = -1/e
                    zp = -1 / e; n = r["n_goals"]
                    S = lambda Y: -zp * np.log2(1 + Y - n)
                    rec(f"prevention form zeta'={zp:g}: S_hat - S_opt", (S(xh) - S(xo)).mean())
                    rec(f"prevention form zeta'={zp:g}: S_mf - S_opt", (S(np.maximum(xm, n)) - S(xo)).mean())
                    rec(f"prevention form zeta'={zp:g}: share of states with S_mf > S_opt", (S(np.maximum(xm, n)) > S(xo) + 1e-9).mean())
                    rec(f"prevention form zeta'={zp:g}: S_gr - S_opt", (S(xg) - S(xo)).mean())
                    rec(f"prevention form zeta'={zp:g}: S_opt", S(xo).mean())
        r = trajectory(P, pi, None)
        v["min: m_hat<=m_gr<=m_opt"] += bool((r["m_hat"] > r["m_gr"] + TOL).any() or (r["m_gr"] > r["m_opt"] + TOL).any())
        if not det:
            rec("min form: log2(m_hat/m_opt)", np.log2(r["m_hat"] / r["m_opt"]).mean())
            rec("min form: log2(m_gr/m_opt)", np.log2(r["m_gr"] / r["m_opt"]).mean())
            rec("min form: log2 m_opt", np.log2(r["m_opt"]).mean())
    return v, gaps

def main(N=5000, seed=1):
    rng = np.random.default_rng(seed)
    for name, v in (("form", check_form(N, rng)), ("veto", check_veto(N, rng))):
        for k, x in v.items(): print(f"[{name}] violations {k}: {int(x)}")
    v, gaps = check_trajectory(N, rng)
    for k, x in v.items(): print(f"[trajectory] violations {k}: {int(x)}")
    print("mean gaps over stochastic instances (bits):")
    for k, x in gaps.items(): print(f"  {k}: {np.mean(x):+.3f}")
    k = 8
    print("open-loop examples, one-step singleton prevention goals:")
    for z in (0, 1.0, np.inf):
        print(f"  zeta'={z}: uniform over {k} actions S={S_prev(np.full(k, 1 - 1 / k), z):+.3f};"
              f" 90% on one of two actions S={S_prev([0.1, 0.9], z):+.3f}")

if __name__ == "__main__":
    main(*(int(a) for a in sys.argv[1:]))
