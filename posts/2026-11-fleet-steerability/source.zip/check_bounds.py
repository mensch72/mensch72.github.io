"""Numerical check of the inequalities in the note
"Steerability of a robot fleet" on random finite instances.

An instance has a finite set of pure overseer strategies sigma, n robots with
finite behaviour sets, and a kernel P[sigma, b_1, ..., b_n].  The overseer is
rational: p(g) = max_sigma P_sigma(g).  Goals are singletons of behaviours.
Usage: python3 check_bounds.py [number_of_instances] [seed]
"""
import itertools, sys
import numpy as np

TOL = 1e-9

def S(pmax, zeta):
    """log2 sum_g p(g)^zeta for an array of maximal goal probabilities."""
    return float(np.log2(np.sum(pmax ** zeta)))

def marginal(P, r):
    axes = tuple(a for a in range(1, P.ndim) if a != r + 1)
    return P.sum(axis=axes)

def steerabilities(P, zeta):
    n = P.ndim - 1
    S_r = [S(marginal(P, r).max(axis=0), zeta) for r in range(n)]
    S_R = S(P.max(axis=0).ravel(), zeta)
    return S_r, S_R

def power(P, f, n_out, zeta):
    """Human power when the outcome is f(joint behaviour), singleton outcome goals."""
    K = P.shape[0]
    flat = P.reshape(K, -1)
    Pout = np.zeros((K, n_out))
    for j, w in enumerate(f):
        Pout[:, w] += flat[:, j]
    pm = Pout.max(axis=0)
    pm = pm[np.bincount(f, minlength=n_out) > 0]
    return S(pm, zeta)

def random_kernel(rng, K, sizes, independent):
    if independent:
        P = np.ones((K,) + tuple(sizes))
        for r, k in enumerate(sizes):
            M = rng.dirichlet(np.full(k, rng.choice([0.2, 1.0, 5.0])), size=K)
            shape = [K] + [1] * len(sizes)
            shape[r + 1] = k
            P = P * M.reshape(shape)
        return P
    a = rng.choice([0.1, 0.5, 2.0])
    return rng.dirichlet(np.full(int(np.prod(sizes)), a), size=K).reshape((K,) + tuple(sizes))

def main(N=20000, seed=1):
    rng = np.random.default_rng(seed)
    viol = {k: 0 for k in ["sandwich_low", "sandwich_up", "zeta1_nonneg", "zeta1_joint_ge_max",
                           "indep_subadd", "F_bounds", "product_additive"]}
    slack = {"sandwich_low": np.inf, "sandwich_up": np.inf}
    for it in range(N):
        n = int(rng.integers(2, 4))
        sizes = [int(rng.integers(2, 4)) for _ in range(n)]
        K = int(rng.integers(1, 6))
        indep = bool(rng.integers(0, 2))
        P = random_kernel(rng, K, sizes, indep)
        J = int(np.prod(sizes))
        n_out = int(rng.integers(1, J + 1))
        f = rng.integers(0, n_out, size=J)
        m = int(np.bincount(f, minlength=n_out).max())
        for zeta in (1.0, 1.5, 2.0, 3.0):
            S_r, S_R = steerabilities(P, zeta)
            I_h = power(P, f, n_out, zeta)
            lo, up = S_R - np.log2(m), S_R + (zeta - 1) * np.log2(m)
            viol["sandwich_low"] += I_h < lo - TOL
            viol["sandwich_up"] += I_h > up + TOL
            slack["sandwich_low"] = min(slack["sandwich_low"], I_h - lo)
            slack["sandwich_up"] = min(slack["sandwich_up"], up - I_h)
            if zeta == 1.0:
                viol["zeta1_nonneg"] += min(S_r) < -TOL
                viol["zeta1_joint_ge_max"] += S_R < max(S_r) - TOL
            if indep:
                viol["indep_subadd"] += S_R > sum(S_r) + TOL
            xi = float(rng.choice([0.5, 1.0, 2.0, 5.0]))
            F = -np.log2(np.sum(2.0 ** (-xi * np.array(S_r)))) / xi
            viol["F_bounds"] += (F > min(S_r) + TOL) or (F < min(S_r) - np.log2(n) / xi - TOL)
        # product case: each robot has its own command, overseer strategy = tuple of commands
        ks = [int(rng.integers(1, 4)) for _ in range(n)]
        Ms = [rng.dirichlet(np.ones(sizes[r]), size=ks[r]) for r in range(n)]
        Pp = np.zeros((int(np.prod(ks)),) + tuple(sizes))
        for i, combo in enumerate(itertools.product(*[range(k) for k in ks])):
            T = np.ones(tuple(sizes))
            for r in range(n):
                shape = [1] * n; shape[r] = sizes[r]
                T = T * Ms[r][combo[r]].reshape(shape)
            Pp[i] = T
        for zeta in (1.0, 2.0):
            S_r, S_R = steerabilities(Pp, zeta)
            viol["product_additive"] += abs(S_R - sum(S_r)) > 1e-7
    print("instances:", N)
    for k, v in viol.items():
        print(f"violations {k}: {int(v)}")
    print("smallest slack, lower / upper sandwich bound:", slack["sandwich_low"], slack["sandwich_up"])

    # worked examples
    k = 5
    # (1) command bottleneck, deterministic: strategies (address robot i, behaviour a), other robot does default 0
    P = np.zeros((2 * k, k, k))
    for a in range(k):
        P[a, a, 0] = 1; P[k + a, 0, a] = 1
    S_r, S_R = steerabilities(P, 2.0)
    print("bottleneck k=5: S_r", S_r, "S_R", S_R, "expected", np.log2(k), np.log2(2 * k - 1))
    # (2) shared coin: b1 fair coin, b2 = b1 xor command
    P = np.zeros((2, 2, 2))
    for x in range(2):
        for c in range(2):
            P[x, c, c ^ x] = 0.5
    for zeta in (1.0, 2.0):
        print("shared coin zeta", zeta, steerabilities(P, zeta))
    # (3) correlated open-loop noise: both robots copy one uniform k-sided die
    P = np.zeros((1, k, k))
    for c in range(k): P[0, c, c] = 1 / k
    print("correlated noise zeta=2:", steerabilities(P, 2.0), "expected S_r", -np.log2(k), "S_R", -np.log2(k))
    # (4) tightness of the upper sandwich bound: one open-loop uniform robot, constant outcome
    P = np.full((1, k), 1 / k)
    for zeta in (1.0, 2.0):
        S_r, S_R = steerabilities(P.reshape(1, k), zeta)
        print("uniform robot, constant outcome, zeta", zeta, "S_R", S_R, "I_h",
              power(P.reshape(1, k), np.zeros(k, dtype=int), 1, zeta), "upper bound", S_R + (zeta - 1) * np.log2(k))

if __name__ == "__main__":
    main(*(int(a) for a in sys.argv[1:]))
